"""Gain from contingency information against headroom above the ceiling.

For every (system, model, converter share), the gain is the mean over seeds of
aware minus blind test accuracy on the test samples at that share, and the
headroom is 100 - A*, with A* the midpoint of the re-simulated bracket at that
share. Writes results/gain3.json and ../paper3/figs/fig_gain.pdf (or out/figs).
"""
import json, os, pickle, sys
import numpy as np
from scipy.stats import pearsonr, spearmanr

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from analysis.analyze3 import per_rho

SUM = json.load(open(os.path.join(HERE, "results", "summary3.json")))
D = os.path.join(HERE, "results", "data2")
FIGDIR = os.path.join(HERE, "..", "paper3", "figs")
if not os.path.isdir(os.path.join(HERE, "..", "paper3")):
    FIGDIR = os.path.join(HERE, "out", "figs")
os.makedirs(FIGDIR, exist_ok=True)
MODELS = {"s9": ["MLP", "GCN", "Het-GNN"], "s39": ["MLP", "GCN", "GAT", "Het-GNN"],
          "s140": ["MLP", "GCN", "Het-GNN"]}
NAMES = {"s9": "WSCC 9-bus", "s39": "IEEE 39-bus", "s140": "NPCC 140-bus"}


def main():
    pts = []
    for tag, models in MODELS.items():
        S = pickle.load(open(os.path.join(D, f"{tag}.pkl"), "rb"))["samples"]
        c = SUM["ceilings"][tag]["dense_by_rho"]
        for m in models:
            b = per_rho(tag, "blind", m, S); a = per_rho(tag, "aware", m, S)
            for r in sorted(c, key=float):
                if r not in b or r not in a:
                    continue
                ceil = 0.5 * (c[r]["loo"] + c[r]["plugin"])
                pts.append(dict(system=tag, model=m, rho=float(r), ceiling=ceil,
                                headroom=100 - ceil, blind=b[r]["mean"], aware=a[r]["mean"],
                                gain=a[r]["mean"] - b[r]["mean"],
                                blind_minus_ceiling=b[r]["mean"] - ceil))
    H = np.array([p["headroom"] for p in pts]); G = np.array([p["gain"] for p in pts])
    BmC = np.array([p["blind_minus_ceiling"] for p in pts])
    slope = float((H @ G) / (H @ H))                       # line through the origin
    out = dict(points=pts, n=len(pts), pearson=float(pearsonr(H, G)[0]),
               spearman=float(spearmanr(H, G).correlation), slope_origin=slope,
               blind_minus_ceiling=dict(mean=float(BmC.mean()), sd=float(BmC.std(ddof=1)),
                                        mad=float(np.mean(np.abs(BmC)))))
    hm = [p for p in pts if p["model"] == "Het-GNN"]
    Hh = np.array([p["headroom"] for p in hm]); Gh = np.array([p["gain"] for p in hm])
    out["hetgnn"] = dict(n=len(hm), pearson=float(pearsonr(Hh, Gh)[0]),
                         spearman=float(spearmanr(Hh, Gh).correlation),
                         slope_origin=float((Hh @ Gh) / (Hh @ Hh)))
    out["by_system"] = {}
    for tag in MODELS:
        q = [p for p in pts if p["system"] == tag]
        f = np.array([p["gain"] / p["headroom"] for p in q if p["headroom"] > 5])
        bm = np.array([p["blind_minus_ceiling"] for p in q])
        out["by_system"][tag] = dict(frac_recovered=float(f.mean()), frac_min=float(f.min()),
                                     frac_max=float(f.max()), n_frac=int(len(f)),
                                     blind_minus_ceiling=float(bm.mean()),
                                     blind_minus_ceiling_mad=float(np.abs(bm).mean()))
    json.dump(out, open(os.path.join(HERE, "results", "gain3.json"), "w"), indent=1)
    print({k: v for k, v in out.items() if k != "points"})

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 9, "axes.edgecolor": "#6b6a64", "xtick.color": "#6b6a64",
                         "ytick.color": "#6b6a64", "legend.frameon": False,
                         "savefig.bbox": "tight"})
    sty = {"s9": ("#1baf7a", "^"), "s39": ("#2a78d6", "s"), "s140": ("#eb6834", "o")}
    fig, ax = plt.subplots(figsize=(4.6, 3.3))
    x = np.linspace(0, max(H) * 1.05, 10)
    ax.plot(x, x, color="#6b6a64", lw=1, ls=":", label="gain = headroom")
    ax.plot(x, slope * x, color="#1f1f1e", lw=1.2, label=f"fit through origin (slope {slope:.2f})")
    for tag in MODELS:
        q = [p for p in pts if p["system"] == tag]
        ax.scatter([p["headroom"] for p in q], [p["gain"] for p in q], s=22, marker=sty[tag][1],
                   color=sty[tag][0], alpha=0.85, lw=0, label=NAMES[tag])
    ax.set_xlabel("headroom above the ceiling, $100 - A^{\\star}$ (points)")
    ax.set_ylabel("gain from contingency inputs (points)")
    ax.grid(color="#e4e3de", lw=0.6); ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.set_xlim(0, None); ax.set_ylim(min(0, G.min() - 1), None)
    ax.legend(fontsize=7.5, loc="upper left")
    fig.savefig(os.path.join(FIGDIR, "fig_gain.pdf"))



if __name__ == "__main__":
    main()
