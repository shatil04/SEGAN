"""Every number in the manuscript, computed from results/data2 and
results/runs3. Writes results/summary3.json and LaTeX tables into out/tables.

Run from the code directory:  python3 analysis/analyze3.py
"""
from __future__ import annotations
import glob
import itertools
import json
import os
import pickle
import sys
from collections import defaultdict

import numpy as np
from scipy.stats import wilcoxon, spearmanr, t as tdist

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from analysis.ceiling import accuracy_bracket, mae_bracket, subsample_k, dense_ceiling

D = os.path.join(HERE, "results", "data2")
RUNS = os.path.join(HERE, "results", "runs3")
TAB = os.path.join(HERE, "out", "tables")
os.makedirs(TAB, exist_ok=True)
RNG = np.random.default_rng(2026)
SYS = {"s9": ("s9.pkl", "dense9.json", "WSCC 9"),
       "s39": ("s39.pkl", "dense39.json", "IEEE 39"),
       "s140": ("s140.pkl", "dense140.json", "NPCC 140")}


def load(f):
    return pickle.load(open(os.path.join(D, f), "rb"))["samples"]


def key(s):
    return s["scenario_id"] + f"|{s['fault_bus']}|{s['trip_branch']}|{s['t_clear']:.4f}"


def holm(p):
    p = np.asarray(p, float)
    o = np.argsort(p)
    adj = np.empty_like(p)
    run = 0.0
    for r, i in enumerate(o):
        run = max(run, (len(p) - r) * p[i])
        adj[i] = min(1.0, run)
    return adj


def mci(v):
    """mean, sd, and half-width of a 95% t-interval over seeds"""
    v = np.asarray(v, float)
    n = len(v)
    sd = v.std(ddof=1) if n > 1 else 0.0
    hw = tdist.ppf(0.975, n - 1) * sd / np.sqrt(n) if n > 1 else 0.0
    return dict(mean=float(v.mean()), sd=float(sd), ci=float(hw), n=n)


def runs(tag):
    out = defaultdict(dict)
    for f in glob.glob(os.path.join(RUNS, f"{tag}__*.json")):
        j = json.load(open(f))
        out[(j["variant"], j["model"])][j["seed"]] = j
    return out


# --------------------------------------------------------------- ceilings
def boot_grouped(S, B=1000):
    groups = defaultdict(list)
    for s in S:
        groups[s["scenario_id"]].append(s)
    G = list(groups.values())
    lo, hi = [], []
    for _ in range(B):
        idx = RNG.integers(0, len(G), len(G))
        # bootstrap duplicates of a group must stay distinct groups
        b = accuracy_bracket([dict(s, scenario_id=f"{n}_{s['scenario_id']}")
                              for n, i in enumerate(idx) for s in G[i]])
        lo.append(b["loo"]); hi.append(b["plugin"])
    return np.percentile(lo, [2.5, 97.5]).tolist(), np.percentile(hi, [2.5, 97.5]).tolist()


def boot_dense(rec, B=2000):
    lo, hi = [], []
    for _ in range(B):
        b = dense_ceiling([rec[i] for i in RNG.integers(0, len(rec), len(rec))])
        lo.append(b["loo"]); hi.append(b["plugin"])
    return np.percentile(lo, [2.5, 97.5]).tolist(), np.percentile(hi, [2.5, 97.5]).tolist()


def ceilings():
    out = {}
    for tag, (f, d, _) in SYS.items():
        S = load(f)
        y = np.mean([s["label"] for s in S])
        e = dict(n=len(S), n_ops=len({s["scenario_id"] for s in S}),
                 stable=100 * y, majority=100 * max(y, 1 - y))
        if tag != "s9":
            e["grouped"] = accuracy_bracket(S)
            e["grouped_ci"] = boot_grouped(S, B=400)
            e["by_k"] = {}
            for k in (2, 4, 8):
                v = [accuracy_bracket(subsample_k(S, k, seed=sd)) for sd in range(5)]
                e["by_k"][k] = dict(loo=float(np.mean([x["loo"] for x in v])),
                                    plugin=float(np.mean([x["plugin"] for x in v])))
        rec = json.load(open(os.path.join(D, d)))
        e["dense"] = dense_ceiling(rec)
        e["dense_ci"] = boot_dense(rec)
        e["dense_by_rho"] = {}
        for r in sorted({x[0] for x in rec}):
            sub = [x for x in rec if abs(x[0] - r) < 1e-9]
            c = dense_ceiling(sub)
            ci = boot_dense(sub, B=1000)
            e["dense_by_rho"][f"{r:.2f}"] = dict(loo=c["loo"], plugin=c["plugin"],
                                                 n=len(sub), loo_ci=ci[0], plugin_ci=ci[1])
        e["majority_by_rho"] = {}
        for r in sorted({s["rho_cap"] for s in S}):
            yy = np.mean([s["label"] for s in S if abs(s["rho_cap"] - r) < 1e-9])
            e["majority_by_rho"][f"{r:.2f}"] = 100 * max(yy, 1 - yy)
        if tag == "s39":
            e["cct_floor"] = mae_bracket(S)
            c = np.array([s["cct"] for s in S]) * 1000
            e["cct_median"] = float(np.median(c))
            e["cct_zero_frac"] = float(np.mean(c <= 0))
            e["cct_cap_frac"] = float(np.mean(c >= 499))
        out[tag] = e
    return out


# --------------------------------------------------------------- models
def model_stats(tag, variants=("blind", "aware", "loc", "tc")):
    rr = runs(tag)
    res = {}
    for (v, m), seeds in rr.items():
        if v not in variants:
            continue
        ss = sorted(seeds)
        e = {k: mci([seeds[s]["task1"][k] for s in ss]) for k in ("acc", "bal_acc", "auc")}
        if all("task2" in seeds[s] for s in ss):
            e["mae"] = mci([seeds[s]["task2"]["mae"] for s in ss])
        res[f"{v}|{m}"] = e
    return res


def pairwise(tag, variant, models):
    rr = runs(tag)
    vec = {m: rr[(variant, m)] for m in models if (variant, m) in rr}
    common = sorted(set.intersection(*[set(v) for v in vec.values()]))
    rows, ps = [], []
    for a, b in itertools.combinations(list(vec), 2):
        x = np.array([vec[a][s]["task1"]["acc"] for s in common])
        y = np.array([vec[b][s]["task1"]["acc"] for s in common])
        d = x - y
        p = 1.0 if np.allclose(d, 0) else float(wilcoxon(x, y).pvalue)
        rows.append(dict(a=a, b=b, median_diff=float(np.median(d)), p=p)); ps.append(p)
    for r, q in zip(rows, holm(ps)):
        r["p_holm"] = float(q)
    return dict(n=len(common), pairs=rows)


def aware_vs_blind(tag, models):
    rr = runs(tag)
    out = {}
    for m in models:
        A, B = rr.get(("aware", m), {}), rr.get(("blind", m), {})
        cs = sorted(set(A) & set(B))
        d = np.array([A[s]["task1"]["acc"] - B[s]["task1"]["acc"] for s in cs])
        out[m] = dict(n=len(cs), wins=int((d > 0).sum()), median=float(np.median(d)),
                      p=float(wilcoxon(d).pvalue) if len(cs) >= 6 else None)
    return out


def per_rho(tag, variant, model, S):
    rr = runs(tag).get((variant, model), {})
    lab = {key(s): (s["label"], s["rho_cap"]) for s in S}
    per_seed = defaultdict(lambda: defaultdict(list))
    for seed, j in rr.items():
        for i, p in zip(j["test_ids"], j["test_p"]):
            y, r = lab[i]
            per_seed[f"{r:.2f}"][seed].append(float((p >= 0.5) == y))
    res = {}
    for r, d in sorted(per_seed.items()):
        accs = [100 * np.mean(v) for v in d.values()]
        res[r] = mci(accs)
    return res


def risk_estimator(tag, model, S):
    rr = runs(tag).get(("blind", model), {})
    lab = {key(s): s["label"] for s in S}
    out = []
    for seed, j in rr.items():
        g = defaultdict(lambda: [[], []])
        for i, p in zip(j["test_ids"], j["test_p"]):
            sid = i.split("|")[0]
            g[sid][0].append(p); g[sid][1].append(lab[i])
        P = np.array([np.mean(v[0]) for v in g.values()])
        F = np.array([np.mean(v[1]) for v in g.values()])
        out.append(dict(brier=float(np.mean((P - F) ** 2)),
                        brier_const=float(np.mean((F.mean() - F) ** 2)),
                        spearman=float(spearmanr(P, F).correlation)))
    return {k: mci([o[k] for o in out]) for k in out[0]} if out else None


# --------------------------------------------------------------- labels
def relabel(S, angle=180.0, nadir=2.5, rocof=2.0, pll_end=None):
    y = []
    for s in S:
        d = s["diag"]
        u = d["diverged"] or d["max_coi_angle_deg"] > angle or \
            d["freq_nadir_hz"] > nadir or d["max_rocof_hz_s"] > rocof
        if pll_end is not None:
            u = u or d.get("pll_end_dev_hz", 0.0) > pll_end
        y.append(0 if u else 1)
    return np.array(y)


def robustness(S, tag):
    y = np.array([s["label"] for s in S])
    rho = np.array([s["rho_cap"] for s in S])
    ang = np.array([s["diag"]["max_coi_angle_deg"] for s in S])
    out = dict(tag=tag, n=len(S), relabel_matches=float(np.mean(relabel(S) == y)),
               gap_120_360=float(100 * np.mean((ang > 120) & (ang < 360))))
    for th in (120, 150, 240, 360):
        out[f"angle_{th}"] = float(100 * np.mean(relabel(S, angle=th) != y))
    out["no_freq"] = float(100 * np.mean(relabel(S, nadir=1e9, rocof=1e9) != y))
    yc = relabel(S, pll_end=0.5)
    ch = yc != y
    out["pll"] = float(100 * ch.mean())
    out["pll_by_rho"] = {f"{r:.2f}": float(100 * ch[rho == r].mean()) for r in sorted(set(rho))}
    Sc = [dict(s, label=int(l)) for s, l in zip(S, yc)]
    out["pll_bracket"] = accuracy_bracket(Sc)
    out["pll_stable"] = float(100 * yc.mean())
    return out, Sc


def main():
    out = {"ceilings": ceilings()}
    S39 = load("s39.pkl"); S140 = load("s140.pkl"); S9 = load("s9.pkl")
    out["robust39"], S39c = robustness(S39, "s39")
    out["robust140"], _ = robustness(S140, "s140")
    pickle.dump(dict(samples=S39c), open(os.path.join(D, "s39_conv.pkl"), "wb"))
    if os.path.isdir(RUNS):
        M = {"s39": ["MLP", "GCN", "GAT", "Het-GNN"], "s9": ["MLP", "GCN", "Het-GNN"],
             "s140": ["MLP", "GCN", "Het-GNN"]}
        Sd = {"s39": S39, "s9": S9, "s140": S140}
        for tag, models in M.items():
            if not runs(tag):
                continue
            out[f"models_{tag}"] = model_stats(tag)
            out[f"pairs_{tag}"] = {v: pairwise(tag, v, models) for v in ("blind", "aware")}
            out[f"avb_{tag}"] = aware_vs_blind(tag, models)
            out[f"rho_{tag}"] = {v: per_rho(tag, v, "Het-GNN", Sd[tag]) for v in ("blind", "aware")}
            if tag != "s9":
                out[f"risk_{tag}"] = {m: risk_estimator(tag, m, Sd[tag]) for m in models}
        if runs("s39conv"):
            out["models_s39conv"] = model_stats("s39conv")
    json.dump(out, open(os.path.join(HERE, "results", "summary3.json"), "w"), indent=1, default=float)
    print("wrote summary3.json")
    return out


# --------------------------------------------------------------- tables
def f1(x):
    return f"{x:.1f}"


def pm(e):
    return f"{e['mean']:.1f}\\,$\\pm$\\,{e['sd']:.1f}"


def write_tables(out):
    C = out["ceilings"]
    best = {}
    for tag in ("s9", "s39", "s140"):
        ms = out.get(f"models_{tag}", {})
        for v in ("blind", "aware"):
            cand = [(e["acc"]["mean"], k.split("|")[1]) for k, e in ms.items() if k.startswith(v + "|")]
            best[(tag, v)] = max(cand) if cand else None

    def bt(tag, v):
        b = best[(tag, v)]
        return f"{b[0]:.1f} ({b[1]})" if b else "---"

    def br(e, ci=None):
        return f"{e['loo']:.1f} / {e['plugin']:.1f}"

    rows = [
        r"Samples / operating points & " + " & ".join(
            f"{C[t]['n']:,} / {C[t]['n_ops']:,}".replace(",", "{,}") for t in ("s9", "s39", "s140")) + r"\\",
        r"Stable fraction (\%) & " + " & ".join(f1(C[t]["stable"]) for t in ("s9", "s39", "s140")) + r"\\",
        r"Majority-class accuracy (\%) & " + " & ".join(f1(C[t]["majority"]) for t in ("s9", "s39", "s140")) + r"\\",
        r"$A^{\star}$, grouped data, $k=8$ (\%) & --- & " + br(C["s39"]["grouped"]) + " & " + br(C["s140"]["grouped"]) + r"\\",
        r"\quad 95\% interval & --- & " + " & ".join(
            f"[{C[t]['grouped_ci'][0][0]:.1f}, {C[t]['grouped_ci'][1][1]:.1f}]" for t in ("s39", "s140")) + r"\\",
        r"$A^{\star}$, re-simulation, $m=32$ (\%) & " + " & ".join(br(C[t]["dense"]) for t in ("s9", "s39", "s140")) + r"\\",
        r"\quad 95\% interval & " + " & ".join(
            f"[{C[t]['dense_ci'][0][0]:.1f}, {C[t]['dense_ci'][1][1]:.1f}]" for t in ("s9", "s39", "s140")) + r"\\",
        r"\midrule",
        r"Best contingency-blind model (\%) & " + " & ".join(bt(t, "blind") for t in ("s9", "s39", "s140")) + r"\\",
        r"Best contingency-aware model (\%) & " + " & ".join(bt(t, "aware") for t in ("s9", "s39", "s140")) + r"\\",
    ]
    body = "\n".join([r"\begin{tabular}{lccc}", r"\toprule",
                      r" & \textbf{WSCC 9} & \textbf{IEEE 39} & \textbf{NPCC 140}\\", r"\midrule"]
                     + rows + [r"\bottomrule", r"\end{tabular}"])
    open(os.path.join(TAB, "tab_ceil.tex"), "w").write("% generated by analysis/analyze3.py\n" + body + "\n")

    # per-system model table
    lines = [r"\begin{tabular}{ll|ccc|cc}", r"\toprule",
             r" & & \multicolumn{3}{c|}{\textbf{Contingency-blind}} & \multicolumn{2}{c}{\textbf{Contingency-aware}}\\",
             r"\textbf{System} & \textbf{Model} & Acc (\%) & Bal.\ acc (\%) & Acc$-A^{\star}$ & Acc (\%) & Bal.\ acc (\%)\\", r"\midrule"]
    for tag, name, models in (("s9", "WSCC 9", ["MLP", "GCN", "Het-GNN"]),
                              ("s39", "IEEE 39", ["MLP", "GCN", "GAT", "Het-GNN"]),
                              ("s140", "NPCC 140", ["MLP", "GCN", "Het-GNN"])):
        ms = out.get(f"models_{tag}")
        if not ms:
            continue
        for i, m in enumerate(models):
            b, a = ms.get(f"blind|{m}"), ms.get(f"aware|{m}")
            if not b or not a:
                continue
            d = out["ceilings"][tag]["dense"]
            gap = b["acc"]["mean"] - 0.5 * (d["loo"] + d["plugin"])
            out.setdefault("gap_to_ceiling", {}).setdefault(tag, {})[m] = dict(gap=gap, ci=b["acc"]["ci"])
            lines.append((name if i == 0 else "") + f" & {m} & {pm(b['acc'])} & {pm(b['bal_acc'])} & "
                         f"${gap:+.1f}\\,\\pm\\,{b['acc']['ci']:.1f}$ & "
                         f"{pm(a['acc'])} & {pm(a['bal_acc'])}" + r"\\")
        if tag != "s140":
            lines.append(r"\midrule")
    lines += [r"\bottomrule", r"\end{tabular}"]
    open(os.path.join(TAB, "tab_models.tex"), "w").write("% generated by analysis/analyze3.py\n" + "\n".join(lines) + "\n")

    # ablation + CCT (39-bus)
    ms = out.get("models_s39", {})
    if all(f"{v}|{m}" in ms for v in ("blind", "tc", "loc", "aware") for m in ("GCN", "Het-GNN")):
        L = [r"\begin{tabular}{lcccc}", r"\toprule",
             r" & \multicolumn{2}{c}{\textbf{GCN}} & \multicolumn{2}{c}{\textbf{Het-GNN}}\\",
             r"\textbf{Input} & Acc (\%) & CCT MAE (ms) & Acc (\%) & CCT MAE (ms)\\", r"\midrule"]
        for v, lab in (("blind", "Blind"), ("tc", "Clearing time only"), ("loc", "Location only"), ("aware", "Aware (both)")):
            L.append(lab + " & " + " & ".join(f"{pm(ms[f'{v}|{m}']['acc'])} & {pm(ms[f'{v}|{m}']['mae'])}"
                                              for m in ("GCN", "Het-GNN")) + r"\\")
        L += [r"\bottomrule", r"\end{tabular}"]
        open(os.path.join(TAB, "tab_ablation.tex"), "w").write("% generated by analysis/analyze3.py\n" + "\n".join(L) + "\n")
    json.dump(out, open(os.path.join(HERE, "results", "summary3.json"), "w"), indent=1, default=float)


if __name__ == "__main__":
    main()
    write_tables(json.load(open(os.path.join(HERE, "results", "summary3.json"))))
