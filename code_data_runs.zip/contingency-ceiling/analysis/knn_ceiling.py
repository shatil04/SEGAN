"""Simulator-free estimate of the contingency-blind accuracy ceiling A* from a
dataset alone, using nearest neighbours in the blind feature space.

For each sample, the k nearest *other* samples (in standardised pre-fault
features) give an estimate p_k(x) of P(stable | x). Two estimates follow:
  plug-in   A_hi(k) = mean max(p_k, 1-p_k)                (biased upwards)
  LOO rule  A_lo(k) = accuracy of the leave-one-out k-NN majority vote
The 1-NN error R1 also gives the Cover-Hart bound A* <= 1 - (1-sqrt(1-2 R1))/2.
Samples from the same operating point (grouped designs) are excluded from each
other's neighbourhoods, so every dataset is treated as a single design.
Writes results/knn3.json.
"""
import json, os, pickle, sys
import numpy as np

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from pihgnn.data.loader import NODE_BASE, EDGE_BASE

D = os.path.join(HERE, "results", "data2")
KS = (1, 5, 11, 21, 41, 81)


def features(samples):
    X = np.stack([np.concatenate([s["graph"]["x"][:, NODE_BASE].ravel(),
                                  s["graph"]["edge_attr"][:, EDGE_BASE].ravel()])
                  for s in samples]).astype(np.float64)
    sd = X.std(0)
    X = X[:, sd > 1e-9]
    X = (X - X.mean(0)) / X.std(0)
    y = np.array([s["label"] for s in samples], dtype=float)
    op = np.array([s["scenario_id"] for s in samples])
    return X, y, op


def features_aware(samples):
    X = np.stack([np.concatenate([s["graph"]["x"].ravel(), s["graph"]["edge_attr"].ravel()])
                  for s in samples]).astype(np.float64)
    X = X[:, X.std(0) > 1e-9]
    return (X - X.mean(0)) / X.std(0)


def knn_bracket(X, y, op, ks=KS, pca=None, chunk=2000):
    if pca:
        U, S, Vt = np.linalg.svd(X - X.mean(0), full_matrices=False)
        X = X @ Vt[:pca].T
    n = len(y); kmax = max(ks)
    nb = np.empty((n, kmax), dtype=np.int64)
    sq = (X ** 2).sum(1)
    for a in range(0, n, chunk):
        b = min(n, a + chunk)
        d = sq[a:b, None] + sq[None, :] - 2 * X[a:b] @ X.T
        same = op[a:b, None] == op[None, :]          # self and same operating point
        d[same] = np.inf
        idx = np.argpartition(d, kmax, axis=1)[:, :kmax]
        dd = np.take_along_axis(d, idx, 1)
        nb[a:b] = np.take_along_axis(idx, np.argsort(dd, 1), 1)
    out = {}
    for k in ks:
        p = y[nb[:, :k]].mean(1)
        hi = np.maximum(p, 1 - p)
        pred = (p > 0.5).astype(float)
        tie = p == 0.5
        pred[tie] = y[nb[tie, 0]]
        lo = (pred == y)
        out[k] = dict(hi=100 * hi.mean(), lo=100 * lo.mean(), _hi=hi, _lo=lo)
    if 1 in out:
        r1 = 1 - out[1]["lo"] / 100
        out["cover_hart_upper"] = 100 * (1 - (1 - np.sqrt(max(0.0, 1 - 2 * r1))) / 2)
    return out


def boot(op, vals, B=1000, seed=0):
    """95% interval resampling operating points."""
    rng = np.random.default_rng(seed)
    u, inv = np.unique(op, return_inverse=True)
    s = np.bincount(inv, vals); c = np.bincount(inv)
    r = [100 * s[i].sum() / c[i].sum() for i in (rng.integers(0, len(u), len(u)) for _ in range(B))]
    return [float(np.percentile(r, 2.5)), float(np.percentile(r, 97.5))]


def single_subsample(X, y, op, seed):
    """One contingency per operating point: emulates a single design."""
    rng = np.random.default_rng(seed)
    keep = []
    for u in np.unique(op):
        ii = np.flatnonzero(op == u)
        keep.append(rng.choice(ii))
    keep = np.array(keep)
    return X[keep], y[keep], op[keep]


def summarise(res, op, k_rep):
    r = res[k_rep]
    return dict(k=k_rep, lo=r["lo"], hi=r["hi"], lo_ci=boot(op, r["_lo"].astype(float)),
                hi_ci=boot(op, r["_hi"]),
                by_k={str(k): dict(lo=res[k]["lo"], hi=res[k]["hi"]) for k in KS},
                cover_hart_upper=res["cover_hart_upper"])


def main():
    out = {}
    K_REP = 21
    # 9-bus: native single design; also a learning curve in n
    S = pickle.load(open(os.path.join(D, "s9.pkl"), "rb"))["samples"]
    X, y, op = features(S)
    out["s9"] = summarise(knn_bracket(X, y, op), op, K_REP)
    out["s9"]["n"] = len(y)
    curve = {}
    rng = np.random.default_rng(1)
    for n in (1000, 2000, 5000, 10000):
        reps = []
        for r in range(5):
            ii = rng.choice(len(y), n, replace=False)
            res = knn_bracket(X[ii], y[ii], op[ii], ks=(K_REP,))
            reps.append((res[K_REP]["lo"], res[K_REP]["hi"]))
        a = np.array(reps)
        curve[str(n)] = dict(lo=float(a[:, 0].mean()), hi=float(a[:, 1].mean()),
                             lo_sd=float(a[:, 0].std()), hi_sd=float(a[:, 1].std()))
    curve[str(len(y))] = dict(lo=out["s9"]["lo"], hi=out["s9"]["hi"], lo_sd=0.0, hi_sd=0.0)
    out["s9"]["curve"] = curve
    print("s9", {k: (round(v["lo"], 1), round(v["hi"], 1)) for k, v in curve.items()})
    # grouped datasets: (a) all samples, same-OP excluded; (b) emulated single design
    for tag, f in (("s39", "s39.pkl"), ("s140", "s140.pkl")):
        S = pickle.load(open(os.path.join(D, f), "rb"))["samples"]
        X, y, op = features(S)
        e = summarise(knn_bracket(X, y, op), op, K_REP)
        e["n"] = len(y)
        reps = []
        for sd in range(5):
            Xs, ys, ops = single_subsample(X, y, op, sd)
            res = knn_bracket(Xs, ys, ops, ks=(K_REP,))
            reps.append((res[K_REP]["lo"], res[K_REP]["hi"]))
        a = np.array(reps)
        e["single"] = dict(n=int(len(np.unique(op))), lo=float(a[:, 0].mean()), hi=float(a[:, 1].mean()),
                           lo_sd=float(a[:, 0].std()), hi_sd=float(a[:, 1].std()))
        out[tag] = e
        print(tag, round(e["lo"], 1), round(e["hi"], 1), e["lo_ci"], e["hi_ci"], "single", e["single"])
    # negative control: contingency-aware features, where the true ceiling is 100%
    for tag, f in (("s9", "s9.pkl"), ("s39", "s39.pkl"), ("s140", "s140.pkl")):
        S = pickle.load(open(os.path.join(D, f), "rb"))["samples"]
        _, y, op = features(S)
        res = knn_bracket(features_aware(S), y, op)
        out[tag]["aware"] = {str(k): dict(lo=res[k]["lo"], hi=res[k]["hi"]) for k in KS}
        print(tag, "aware", {k: (round(res[k]["lo"], 1), round(res[k]["hi"], 1)) for k in KS})
    json.dump(out, open(os.path.join(HERE, "results", "knn3.json"), "w"), indent=1)
    print(json.dumps({t: {k: out[t][k] for k in ("by_k", "cover_hart_upper")} for t in out}, indent=0))


if __name__ == "__main__":
    main()
