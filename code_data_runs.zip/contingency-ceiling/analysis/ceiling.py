"""Estimators for the contingency-marginal Bayes ceiling.

When a model sees only the pre-fault state x, the label it is asked to predict
is y = f(x, c) with the contingency c drawn from the dataset's contingency
distribution. The best achievable accuracy is

    A* = E_x[ max(p(x), 1 - p(x)) ],   p(x) = P(y = 1 | x),

and for critical-clearing-time regression the smallest achievable mean absolute
error is

    M* = E_x[ E| CCT - median(CCT | x) | ].

Both are properties of the dataset, not of any model. With k contingencies
observed per operating point they can be bracketed:

  plug-in      majority (median) of all k labels; optimistic for A*, since
               max(p_hat, 1 - p_hat) is biased upward by Jensen's inequality,
               and optimistic (low) for M*.
  leave-one-out each sample is predicted from the other k - 1 labels of its
               operating point; this is the accuracy of a realisable plug-in
               rule and is therefore pessimistic for A* (high for M*).
"""
from __future__ import annotations
from collections import defaultdict
import numpy as np


def _groups(samples):
    g = defaultdict(list)
    for s in samples:
        g[s["scenario_id"]].append(s)
    return g


def accuracy_bracket(samples, prior=None):
    g = _groups(samples)
    ys = np.array([s["label"] for s in samples])
    prior = ys.mean() if prior is None else prior
    plug_num = loo_num = n = 0
    for grp in g.values():
        y = np.array([s["label"] for s in grp])
        k = len(y)
        n += k
        plug_num += max(y.sum(), k - y.sum())
        if k == 1:
            loo_num += float(y[0] == (prior >= 0.5))
            continue
        for i in range(k):
            ones = y.sum() - y[i]
            zeros = (k - 1) - ones
            if ones > zeros:
                pred = 1
            elif zeros > ones:
                pred = 0
            else:
                pred = int(prior >= 0.5)
            loo_num += float(pred == y[i])
    return dict(plugin=100 * plug_num / n, loo=100 * loo_num / n, n=n,
                n_groups=len(g), k_mean=n / len(g))


def mae_bracket(samples):
    g = _groups(samples)
    plug, loo, n = 0.0, 0.0, 0
    for grp in g.values():
        c = np.array([s["cct"] for s in grp if s.get("cct") is not None]) * 1000.0
        k = len(c)
        if k == 0:
            continue
        n += k
        plug += np.abs(c - np.median(c)).sum()
        if k > 1:
            for i in range(k):
                loo += abs(c[i] - np.median(np.delete(c, i)))
        else:
            loo += 0.0
    return dict(plugin=plug / n, loo=loo / n, n=n)


def subsample_k(samples, k, seed=0):
    """Keep k contingencies per operating point (for studying how the plug-in
    estimate depends on k)."""
    rng = np.random.default_rng(seed)
    out = []
    for grp in _groups(samples).values():
        if len(grp) >= k:
            idx = rng.choice(len(grp), size=k, replace=False)
            out += [grp[i] for i in idx]
    return out


def dense_ceiling(records):
    """records: list of (rho, p_hat, m) from Monte-Carlo resimulation with m
    contingencies per operating point. Returns plug-in and LOO-style bracket."""
    P = np.array([r[1] for r in records])
    M = np.array([r[2] for r in records])
    plug = np.maximum(P, 1 - P).mean()
    # leave-one-out for each of the m draws of each operating point
    loo = []
    for p, m in zip(P, M):
        ones = int(round(p * m))
        acc = 0.0
        for y, cnt in ((1, ones), (0, m - ones)):
            o = ones - (y == 1)
            z = (m - 1) - o
            pred = 1 if o > z else 0 if z > o else 1
            acc += cnt * (pred == y)
        loo.append(acc / m)
    return dict(plugin=100 * plug, loo=100 * float(np.mean(loo)), n_ops=len(P),
                m=int(M[0]) if len(M) else 0)
