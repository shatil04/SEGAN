"""Figures from results/summary3.json and the run files. Series are told apart
by marker shape and line style as well as colour."""
import json, os, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from analysis.analyze3 import runs

OUT = os.path.join(HERE, "out", "figs")
os.makedirs(OUT, exist_ok=True)
SUM = json.load(open(os.path.join(HERE, "results", "summary3.json")))
C = dict(blue="#2a78d6", orange="#eb6834", aqua="#1baf7a")
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e4e3de"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.titlesize": 9.5,
                     "legend.frameon": False, "savefig.bbox": "tight", "figure.dpi": 200})
NAMES = {"s9": "WSCC 9-bus", "s39": "IEEE 39-bus", "s140": "NPCC 140-bus"}


def _axes(ax):
    ax.grid(axis="y", color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)


def fig_k():
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.8))
    for ax, tag in zip(axs, ("s39", "s140")):
        e = SUM["ceilings"][tag]
        ks = [2, 4, 8]
        hi = [e["by_k"][str(k)]["plugin"] for k in ks]
        lo = [e["by_k"][str(k)]["loo"] for k in ks]
        d = e["dense"]
        ax.axhspan(e["dense_ci"][0][0], e["dense_ci"][1][1], color=C["aqua"], alpha=0.12, lw=0,
                   label="re-simulation, 95% interval")
        ax.axhspan(d["loo"], d["plugin"], color=C["aqua"], alpha=0.35, lw=0,
                   label=f"re-simulation bracket, $m={d['m']}$")
        ax.plot(ks, hi, "-o", color=C["orange"], lw=2, ms=6, label="plug-in (upper)")
        ax.plot(ks, lo, "--s", color=C["blue"], lw=2, ms=6, label="leave-one-out (lower)")
        ax.set_xticks(ks)
        ax.set_xlabel("contingencies observed per operating point, $k$")
        ax.set_title(NAMES[tag], color=INK)
        _axes(ax)
    axs[0].set_ylabel("estimate of $A^\\star$ (%)")
    h, l = axs[0].get_legend_handles_labels()
    fig.subplots_adjust(bottom=0.33, wspace=0.28)
    fig.legend(h, l, loc="lower center", ncol=2, fontsize=7.5, bbox_to_anchor=(0.5, 0.0))
    fig.savefig(os.path.join(OUT, "fig_k.pdf"))
    plt.close(fig)


def fig_rho():
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.4))
    for ax, tag in zip(axs, ("s39", "s140")):
        e = SUM["ceilings"][tag]
        rhos = sorted(e["dense_by_rho"], key=float)
        x = [100 * float(r) for r in rhos]
        lo = [e["dense_by_rho"][r]["loo_ci"][0] for r in rhos]
        hi = [e["dense_by_rho"][r]["plugin_ci"][1] for r in rhos]
        blo = [e["dense_by_rho"][r]["loo"] for r in rhos]
        bhi = [e["dense_by_rho"][r]["plugin"] for r in rhos]
        ax.fill_between(x, lo, hi, color=C["aqua"], alpha=0.14, lw=0, label="ceiling, 95% interval")
        ax.fill_between(x, blo, bhi, color=C["aqua"], alpha=0.40, lw=0, label="ceiling $A^\\star$ (bracket)")
        mrho = sorted(e["majority_by_rho"], key=float)
        ax.plot([100 * float(r) for r in mrho], [e["majority_by_rho"][r] for r in mrho],
                ":", color=MUTED, lw=1.6, label="majority class")
        for v, col, mk, ls in (("blind", C["blue"], "s", "--"), ("aware", C["orange"], "o", "-")):
            pr = SUM[f"rho_{tag}"][v]
            rr = sorted(pr, key=float)
            xs = [100 * float(r) for r in rr]
            ax.errorbar(xs, [pr[r]["mean"] for r in rr], yerr=[pr[r]["ci"] for r in rr],
                        fmt=mk + ls, color=col, lw=2, ms=5, capsize=2,
                        label=f"Het-GNN, contingency-{v}")
        ax.set_xlabel("converter share of installed capacity (%)")
        ax.set_title(NAMES[tag], color=INK)
        ax.set_ylim(40, 101)
        _axes(ax)
    axs[0].set_ylabel("test accuracy (%)")
    h, l = axs[0].get_legend_handles_labels()
    fig.subplots_adjust(bottom=0.32, wspace=0.25)
    fig.legend(h, l, loc="lower center", ncol=3, fontsize=7.5, bbox_to_anchor=(0.5, 0.0))
    fig.savefig(os.path.join(OUT, "fig_rho.pdf"))
    plt.close(fig)


def fig_seeds():
    rr = runs("s39")
    models = ["MLP", "GCN", "GAT", "Het-GNN"]
    fig, ax = plt.subplots(figsize=(7.0, 2.8))
    rng = np.random.default_rng(0)
    for i, m in enumerate(models):
        for v, col, mk, dx in (("blind", C["blue"], "s", -0.15), ("aware", C["orange"], "o", 0.15)):
            vals = [j["task1"]["acc"] for j in rr.get((v, m), {}).values()]
            if not vals:
                continue
            xs = i + dx + rng.uniform(-0.05, 0.05, len(vals))
            ax.scatter(xs, vals, s=14, marker=mk, color=col, alpha=0.8, lw=0,
                       label=f"contingency-{v}" if i == 0 else None)
            ax.hlines(np.mean(vals), i + dx - 0.1, i + dx + 0.1, color=INK, lw=1.4)
    d = SUM["ceilings"]["s39"]["dense"]
    ax.axhspan(d["loo"], d["plugin"], color=C["aqua"], alpha=0.35, lw=0,
               label="ceiling $A^\\star$ (bracket)")
    ax.set_xticks(range(len(models)))
    ax.set_xticklabels(models)
    ax.set_ylabel("test accuracy (%)")
    _axes(ax)
    ax.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), fontsize=7.5)
    fig.savefig(os.path.join(OUT, "fig_seeds.pdf"))
    plt.close(fig)


if __name__ == "__main__":
    for f in sys.argv[1:] or ["k", "rho", "seeds"]:
        globals()[f"fig_{f}"]()
        print("wrote", f)
