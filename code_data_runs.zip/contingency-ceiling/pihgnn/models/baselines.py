"""Models for stability classification and CCT regression: a topology-agnostic
MLP, GCN, GAT and a heterogeneous GNN with node-type-specific input encoders.
Every model returns (logits, aux, h[, cct]); `aux` is None.
"""
from __future__ import annotations
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, GATConv, SAGEConv, global_mean_pool, global_add_pool


def readout(h, batch):
    """Graph-level readout: mean over buses concatenated with the embedding
    at the faulted bus. For contingency-blind inputs the fault mask is zero,
    so the second half carries no information and capacity is identical."""
    fm = getattr(batch, "fmask", None)
    if fm is None:
        fm = h.new_zeros(h.size(0))
    return torch.cat([global_mean_pool(h, batch.batch),
                      global_add_pool(h * fm.view(-1, 1), batch.batch)], dim=1)


class MLP(nn.Module):
    """Node-feature-averaging MLP; ignores topology (lower bound)."""

    def __init__(self, in_dim=13, hidden=64, dropout=0.1, **_):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2 * in_dim, hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden), nn.ReLU())
        self.head = nn.Linear(hidden, 2)
        self.cct_head = nn.Linear(hidden, 1)   # Eq. (17)

    def forward(self, batch):
        z = self.net(readout(batch.x, batch))
        return self.head(z), None, None, F.softplus(self.cct_head(z)).squeeze(-1)


class _GNN(nn.Module):
    def __init__(self, conv_cls, in_dim=13, hidden=64, layers=3, dropout=0.1,
                 **kw):
        super().__init__()
        self.inp = nn.Linear(in_dim, hidden)
        self.convs = nn.ModuleList(
            [conv_cls(hidden, hidden, **kw) for _ in range(layers)])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden) for _ in range(layers)])
        self.cct_head = nn.Linear(2 * hidden, 1)   # Eq. (17)
        self.head = nn.Sequential(nn.Linear(2 * hidden, hidden), nn.ReLU(),
                                  nn.Dropout(dropout), nn.Linear(hidden, 2))

    def forward(self, batch):
        h = F.relu(self.inp(batch.x))
        for conv, norm in zip(self.convs, self.norms):
            h = norm(h + F.relu(conv(h, batch.edge_index)))
        g = readout(h, batch)
        return self.head(g), None, h, F.softplus(self.cct_head(g)).squeeze(-1)


def GCN(**kw):
    return _GNN(GCNConv, **kw)


def GAT(in_dim=13, hidden=64, layers=3, heads=4, dropout=0.1, **_):
    # GATConv changes dim by heads; wrap to keep hidden width constant
    class _GAT(_GNN):
        def __init__(self):
            nn.Module.__init__(self)
            self.inp = nn.Linear(in_dim, hidden)
            self.convs = nn.ModuleList(
                [GATConv(hidden, hidden // heads, heads=heads, dropout=dropout)
                 for _ in range(layers)])
            self.norms = nn.ModuleList(
                [nn.LayerNorm(hidden) for _ in range(layers)])
            self.cct_head = nn.Linear(2 * hidden, 1)   # Eq. (17)
            self.head = nn.Sequential(nn.Linear(2 * hidden, hidden), nn.ReLU(),
                                      nn.Dropout(dropout), nn.Linear(hidden, 2))
    return _GAT()


class HetGNN(nn.Module):
    """Heterogeneous GNN: node-type-specific input encoders followed by shared
    message passing; topology and device type both enter the representation."""

    def __init__(self, in_dim=13, hidden=64, layers=3, n_types=4, dropout=0.1,
                 **_):
        super().__init__()
        self.encoders = nn.ModuleList(
            [nn.Linear(in_dim, hidden) for _ in range(n_types)])
        self.convs = nn.ModuleList(
            [SAGEConv(hidden, hidden) for _ in range(layers)])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden) for _ in range(layers)])
        self.cct_head = nn.Linear(2 * hidden, 1)   # Eq. (17)
        self.head = nn.Sequential(nn.Linear(2 * hidden, hidden), nn.ReLU(),
                                  nn.Dropout(dropout), nn.Linear(hidden, 2))
        self.n_types = n_types

    def forward(self, batch):
        x = batch.x
        h = x.new_zeros((x.size(0), self.encoders[0].out_features))
        for t in range(self.n_types):
            m = batch.ntype == t
            if m.any():
                h[m] = self.encoders[t](x[m])
        for conv, norm in zip(self.convs, self.norms):
            h = norm(h + F.relu(conv(h, batch.edge_index)))
        g = readout(h, batch)
        return self.head(g), None, h, F.softplus(self.cct_head(g)).squeeze(-1)


REGISTRY = dict(mlp=MLP, gcn=GCN, gat=GAT, hetgnn=HetGNN)
