"""Experiment driver for the contingency-identifiability study.

One run = (dataset, feature variant, model, seed). Results are written as one
JSON file per run into $RUNS_DIR (default results/runs3/), named

    {data_tag}__{variant}__{model}__seed{NNN}.json

Usage:
    python -m pihgnn.experiments.bench2 --data results/data2/s39.pkl --tag s39 \
        --variants aware,blind --models mlp,gcn --seeds 10 --epochs 40
"""
from __future__ import annotations
import argparse
import json
import os
import time
import numpy as np
import torch

RUNS = os.environ.get("RUNS_DIR", "results/runs3")
NAME = {"mlp": "MLP", "gcn": "GCN", "gat": "GAT", "hetgnn": "Het-GNN"}


def _path(tag, variant, model, seed):
    return f"{RUNS}/{tag}__{variant}__{NAME[model]}__seed{seed:03d}.json"


def _cct_metrics(model, loader):
    model.eval()
    ys, ps = [], []
    with torch.no_grad():
        for b in loader:
            out = model(b)
            if len(out) < 4 or not hasattr(b, "cct"):
                return None
            ys.append(b.cct.view(-1).numpy())
            ps.append(out[3].view(-1).numpy())
    y = np.concatenate(ys) * 1000.0
    p = np.concatenate(ps) * 1000.0
    return dict(mae=float(np.abs(y - p).mean()),
                rmse=float(np.sqrt(((y - p) ** 2).mean())),
                r2=float(1 - ((y - p) ** 2).sum() / max(((y - y.mean()) ** 2).sum(), 1e-9)))


def run_one(samples, variant, model_name, seed, epochs, split):
    from ..data.loader import make_loaders, select_features
    from ..train.trainer import train_model, evaluate
    from ..models.baselines import REGISTRY

    torch.manual_seed(seed)
    np.random.seed(seed)
    tr, va, te = split(samples, seed)
    tr, va, te = (select_features(x, variant) for x in (tr, va, te))
    loaders = make_loaders(tr, va, te)
    in_dim = tr[0]["graph"]["x"].shape[1]
    net = REGISTRY[model_name](in_dim=in_dim)
    net, _ = train_model(net, loaders, epochs=epochs)
    m = evaluate(net, loaders[2])
    y, p = m["_y"], m["_p"]
    pred = (p >= 0.5).astype(int)
    tpr = float((pred[y == 1] == 1).mean()) if (y == 1).any() else float("nan")
    tnr = float((pred[y == 0] == 0).mean()) if (y == 0).any() else float("nan")
    out = dict(task1=dict(acc=100 * m["acc"], f1=100 * m["f1"],
                          auc=100 * m["auc"], fnr=100 * m["fnr"],
                          bal_acc=100 * 0.5 * (tpr + tnr)),
               n_test=int(len(y)), test_stable_frac=float(y.mean()))
    c = _cct_metrics(net, loaders[2])
    if c:
        out["task2"] = c
    # per-sample test predictions, for ceiling comparisons by subgroup
    out["test_ids"] = [s["scenario_id"] + f"|{s['fault_bus']}|{s['trip_branch']}|{s['t_clear']:.4f}"
                       for s in te]
    out["test_p"] = [float(v) for v in p]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--variants", default="aware,blind")
    ap.add_argument("--models", default="mlp,gcn,gat,hetgnn")
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--seed0", type=int, default=0)
    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--budget", type=float, default=1e9)
    a = ap.parse_args()

    torch.set_num_threads(1)
    from ..data.loader import load_samples, random_split
    samples = load_samples(a.data)
    split = lambda x, sd: random_split(x, seed=sd)
    os.makedirs(RUNS, exist_ok=True)
    t0 = time.time()
    for s in range(a.seed0, a.seed0 + a.seeds):
        for v in a.variants.split(","):
            for m in a.models.split(","):
                path = _path(a.tag, v, m, s)
                if os.path.exists(path):
                    continue
                if time.time() - t0 > a.budget:
                    print("budget reached", flush=True)
                    return
                t1 = time.time()
                out = run_one(samples, v, m, s, a.epochs, split)
                out.update(tag=a.tag, variant=v, model=NAME[m], seed=s,
                           epochs=a.epochs, seconds=time.time() - t1)
                with open(path, "w") as f:
                    json.dump(out, f)
                print(f"{a.tag} {v:<6} {NAME[m]:<8} seed {s:>2}: "
                      f"acc={out['task1']['acc']:.1f} "
                      f"bal={out['task1']['bal_acc']:.1f} "
                      f"({out['seconds']:.0f}s)", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
