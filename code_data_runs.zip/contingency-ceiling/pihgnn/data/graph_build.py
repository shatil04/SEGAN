"""Heterogeneous graph construction.

Each bus is a node with a type in {SG, GFM, GFL, BUS}. Node features encode the
physical parameters of each device (inertia,
damping, reactance, setpoints, local load). Edges are transmission branches,
carrying series admittance magnitude/angle used by the admittance-weighted
attention. The output is framework-agnostic (numpy); `to_pyg` converts a sample
to a torch_geometric HeteroData / Data object on the author's machine.
"""
from __future__ import annotations
import numpy as np

NODE_TYPES = ["SG", "GFM", "GFL", "BUS"]
NTYPE_IDX = {t: i for i, t in enumerate(NODE_TYPES)}


def apply_contingency(graph, net, fault_bus, trip_branch, t_clear, case):
    """Attach contingency identity to a pre-fault graph.

    Without this the model receives an input that is identical for every
    contingency applied to the same operating point, while the labels differ --
    the fault location and clearing time are what decide stability. Predicting
    them from a fault-independent input is not possible even in principle, so
    the contingency must be part of the input.

    Adds four node features and one edge feature:
        is_fault_bus      1 at the faulted bus
        is_trip_endpoint  1 at either endpoint of the tripped branch
        t_clear           clearing time, broadcast (graph-level scalar)
        hops_to_fault     shortest-path distance to the faulted bus, normalised
        is_tripped        (edge) 1 on both directions of the tripped branch
    """
    import collections
    g = dict(graph)
    nb = g["x"].shape[0]
    k_fault = net.bidx[int(fault_bus)]

    br = case["branch"][int(trip_branch)]
    f_end, t_end = net.bidx[int(br[0])], net.bidx[int(br[1])]

    # breadth-first hop distance from the faulted bus over in-service branches
    adj = collections.defaultdict(list)
    ei = g["edge_index"]
    for a, b in zip(ei[0], ei[1]):
        adj[int(a)].append(int(b))
    dist = np.full(nb, -1.0, dtype=np.float32)
    dist[k_fault] = 0.0
    frontier = [k_fault]
    while frontier:
        nxt = []
        for u in frontier:
            for v in adj[u]:
                if dist[v] < 0:
                    dist[v] = dist[u] + 1.0
                    nxt.append(v)
        frontier = nxt
    dist[dist < 0] = dist.max() + 1.0 if dist.max() > 0 else 1.0
    dist = dist / max(dist.max(), 1.0)

    extra = np.zeros((nb, 4), dtype=np.float32)
    extra[k_fault, 0] = 1.0
    extra[f_end, 1] = 1.0
    extra[t_end, 1] = 1.0
    extra[:, 2] = float(t_clear)
    extra[:, 3] = dist
    g["x"] = np.concatenate([g["x"], extra], axis=1)

    ea = g["edge_attr"]
    tripped = np.zeros((ea.shape[0], 1), dtype=np.float32)
    for e in range(ea.shape[0]):
        a, b = int(ei[0, e]), int(ei[1, e])
        if {a, b} == {f_end, t_end}:
            tripped[e, 0] = 1.0
    g["edge_attr"] = np.concatenate([ea, tripped], axis=1)
    return g


def build_graph(net, operating_point=None):
    """Construct node features X, edge_index, edge_attr, and node type ids.

    Node features (per bus), all in pu on system base:
      [onehot(SG,GFM,GFL,BUS)(4),
       H_or_J, D_or_Dp, Xsrc, Pset, Qset, Vmag, Pd, Qd, is_gen]
    Edge features (per directed branch):
      [G_series, B_series, |Y_series|, B_charging]
    """
    case = net.case
    bus = case["bus"]
    branch = case["branch"]
    nb = bus.shape[0]
    V = getattr(net, "Vpf", bus[:, 7] * np.exp(1j * np.deg2rad(bus[:, 8])))

    ntype = np.full(nb, NTYPE_IDX["BUS"], dtype=np.int64)
    for b, d in net.devices.items():
        ntype[net.bidx[b]] = NTYPE_IDX[d["type"]]

    X = np.zeros((nb, 4 + 9), dtype=np.float32)
    for k in range(nb):
        X[k, ntype[k]] = 1.0
        X[k, 4 + 5] = float(abs(V[k]))                 # Vmag
        X[k, 4 + 6] = bus[k, 2] / case["baseMVA"]      # Pd
        X[k, 4 + 7] = bus[k, 3] / case["baseMVA"]      # Qd
    for b, d in net.devices.items():
        k = net.bidx[b]
        X[k, 4 + 0] = d.get("H", d.get("J", 0.0))      # inertia (H or virtual J)
        X[k, 4 + 1] = d.get("D", d.get("Dp", 0.0))     # damping
        X[k, 4 + 2] = net.xsrc[b]                       # source reactance
        X[k, 4 + 3] = net.Pset.get(b, 0.0)             # active setpoint
        X[k, 4 + 4] = 0.0                               # reactive setpoint (opt.)
        X[k, 4 + 8] = 1.0                               # is_gen flag

    ei, ea = [], []
    for br in branch:
        if br[10] == 0:
            continue
        f, t = net.bidx[int(br[0])], net.bidx[int(br[1])]
        r, x, bc = br[2], br[3], br[4]
        ys = 1.0 / (r + 1j * x)
        feat = [ys.real, ys.imag, abs(ys), bc / 2.0]
        ei += [[f, t], [t, f]]
        ea += [feat, feat]
    edge_index = np.array(ei, dtype=np.int64).T
    edge_attr = np.array(ea, dtype=np.float32)
    return dict(x=X, edge_index=edge_index, edge_attr=edge_attr, ntype=ntype)


def to_pyg(sample):
    """Convert a numpy graph sample + label to a torch_geometric Data object.
    Imported lazily so dataset generation does not require torch."""
    import torch
    from torch_geometric.data import Data
    g = sample["graph"]
    data = Data(
        x=torch.tensor(g["x"]),
        edge_index=torch.tensor(g["edge_index"]),
        edge_attr=torch.tensor(g["edge_attr"]),
    )
    data.ntype = torch.tensor(g["ntype"])
    data.fmask = torch.tensor(g.get("fmask", np.zeros(g["x"].shape[0], np.float32)))
    data.y = torch.tensor([sample["label"]], dtype=torch.long)
    if "cct" in sample and sample["cct"] is not None:
        data.cct = torch.tensor([sample["cct"]], dtype=torch.float32)
    data.rho_cap = torch.tensor([sample.get("rho_cap", 0.0)], dtype=torch.float32)
    data.rho_disp = torch.tensor([sample.get("rho_disp", 0.0)], dtype=torch.float32)
    # unscaled physical quantities, kept alongside the scaled features
    raw = g.get("x_raw", g["x"])   
    data.Pset = torch.tensor(raw[:, 4 + 3])
    data.H = torch.tensor(raw[:, 4 + 0])
    data.D = torch.tensor(raw[:, 4 + 1])
    return data
