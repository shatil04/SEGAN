"""Dataset generation for the contingency-identifiability study.

Two dataset designs are supported, matching the two constructions found in the
learning-based DSA literature:

  grouped   n operating points per penetration level, k contingencies applied
            to each (each contingency = fault bus, tripped incident branch,
            clearing time drawn from a discrete set). Several samples share one
            pre-fault state.
  single    every sample is a fresh operating point with one contingency: a
            random fault bus and a clearing time drawn uniformly from an
            interval. No pre-fault state repeats.

Every sample stores the contingency-aware graph (pre-fault features plus
contingency descriptors), the label, optional critical clearing time, and the
raw stability margins needed for relabelling under other criteria.
"""
from __future__ import annotations
import numpy as np

from .systems import get_system
from .case39 import build_ybus, make_penetration_config
from . import dynamics as dyn
from .graph_build import build_graph, apply_contingency


def _connected_without(case, skip):
    """True if the in-service network stays connected with branch `skip` out."""
    br = case["branch"]
    nodes = {int(b) for b in case["bus"][:, 0]}
    adj = {n: [] for n in nodes}
    for j, b in enumerate(br):
        if j == skip or b[10] == 0:
            continue
        adj[int(b[0])].append(int(b[1]))
        adj[int(b[1])].append(int(b[0]))
    start = next(iter(nodes))
    seen, stack = {start}, [start]
    while stack:
        u = stack.pop()
        for v in adj[u]:
            if v not in seen:
                seen.add(v)
                stack.append(v)
    return len(seen) == len(nodes)


_NONISL = {}


def _incident(case, fb):
    """Branches incident to bus fb whose tripping does NOT island any bus.

    Tripping the only link of a generator or load bus separates it from the
    network; the resulting 'instability' is a loss of generation or load, not
    transient instability, and such contingencies are conventionally excluded
    from transient-stability studies. They are excluded here."""
    key = id(case["branch"])
    if key not in _NONISL:
        _NONISL[key] = {j for j in range(len(case["branch"]))
                        if case["branch"][j][10] != 0 and _connected_without(case, j)}
    ok = _NONISL[key]
    return [j for j, br in enumerate(case["branch"])
            if j in ok and (int(br[0]) == fb or int(br[1]) == fb)]


def _scale(case, factor, rng):
    c = dict(case)
    bus = case["bus"].copy()
    jit = 1.0 + rng.uniform(-0.05, 0.05, size=bus.shape[0])
    bus[:, 2] *= factor * jit
    bus[:, 3] *= factor * jit
    c["bus"] = bus
    gen = case["gen"].copy()
    gen[:, 1] *= factor
    c["gen"] = gen
    return c


def _dispatch_share(net):
    ibr = sum(net.Pset[b] for b in net.dev_bus
              if net.devices[b]["type"] in ("GFM", "GFL"))
    tot = sum(net.Pset[b] for b in net.dev_bus)
    return float(max(ibr, 0.0) / max(tot, 1e-9))


def make_op(S, rho, rng, load_range=(0.8, 1.15)):
    """Sample one operating point; returns (case, net, y0, layout) or None."""
    factor = float(rng.uniform(*load_range))
    case = _scale(S["case"], factor, rng)
    cfg = make_penetration_config(case, rho_cap=rho, gfm_gfl_ratio=(1, 2),
                                  rng=rng, gen_dyn=S["gen_dyn"],
                                  exclude=S["exclude"])
    net = dyn.Network(case, build_ybus(case), cfg["devices"])
    try:
        y0, layout = dyn.initialise(net)
    except Exception:
        return None
    if not np.isfinite(y0).all():
        return None
    return case, net, y0, layout, factor


def draw_contingency(case, net, rng, clearing):
    """clearing: list -> discrete choice; (lo, hi) tuple -> uniform."""
    for _ in range(50):
        fb = int(rng.choice(net.bus_ids))
        inc = _incident(case, fb)
        if inc:
            break
    tb = int(rng.choice(inc))
    if isinstance(clearing, tuple):
        tc = float(rng.uniform(*clearing))
    else:
        tc = float(rng.choice(clearing))
    return fb, tb, tc


def generate(system, rho_levels, ops_per_level, k, clearing, seed,
             compute_cct=False, design="grouped", load_range=(0.8, 1.15)):
    S = get_system(system)
    rng = np.random.default_rng(seed)
    out = []
    for rho in rho_levels:
        made = tries = 0
        while made < ops_per_level and tries < 5 * ops_per_level:
            tries += 1
            op = make_op(S, rho, rng, load_range)
            if op is None:
                continue
            case, net, y0, layout, factor = op
            base = build_graph(net)
            sid = f"{system}_r{rho:.2f}_s{made:05d}"
            n_c = k if design == "grouped" else 1
            if design == "grouped":
                elig = [b for b in net.bus_ids if _incident(case, int(b))]
                buses = rng.choice(elig, size=min(k, len(elig)), replace=False)
            for c in range(n_c):
                if design == "grouped":
                    fb = int(buses[c])
                    inc = _incident(case, fb)
                    if not inc:
                        continue
                    tb = int(rng.choice(inc))
                    tc = float(rng.choice(clearing)) if not isinstance(
                        clearing, tuple) else float(rng.uniform(*clearing))
                else:
                    fb, tb, tc = draw_contingency(case, net, rng, clearing)
                lab, diag = dyn.label_and_diagnostics(net, y0, layout, fb, tb, tc)
                g = apply_contingency(base, net, fb, tb, tc, case)
                smp = dict(graph=g, label=int(lab), rho_cap=float(rho),
                           rho_disp=_dispatch_share(net), fault_bus=fb,
                           trip_branch=tb, t_clear=tc, load_factor=factor,
                           scenario_id=sid, system=system, diag=diag)
                if compute_cct:
                    smp["cct"] = float(dyn.critical_clearing_time(
                        net, y0, layout, fb, tb))
                out.append(smp)
            made += 1
    return out


def conditional_stability(system, rho, n_ops, m, clearing, seed,
                          load_range=(0.8, 1.15)):
    """Monte-Carlo estimate of p(x) = P(stable | pre-fault state x) under the
    contingency distribution, for n_ops fresh operating points with m
    contingencies each. Returns a list of (rho, p_hat, m)."""
    S = get_system(system)
    rng = np.random.default_rng(seed)
    res = []
    made = tries = 0
    while made < n_ops and tries < 5 * n_ops:
        tries += 1
        op = make_op(S, rho, rng, load_range)
        if op is None:
            continue
        case, net, y0, layout, _ = op
        labs = []
        for _ in range(m):
            fb, tb, tc = draw_contingency(case, net, rng, clearing)
            labs.append(dyn._label_for_clear(net, y0, layout, fb, tb, tc))
        res.append((float(rho), float(np.mean(labs)), m))
        made += 1
    return res
