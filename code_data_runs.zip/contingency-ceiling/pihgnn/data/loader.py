"""Torch dataset / dataloader over generated samples.

Loads the pickles produced by the generators, selects the feature variant
(contingency-blind, -aware, or partial), converts each sample to a PyG `Data`,
and provides splits by operating point. Requires torch + torch_geometric.
"""
from __future__ import annotations
import pickle
import numpy as np
from torch_geometric.data import InMemoryDataset
from torch_geometric.loader import DataLoader

from ..data.graph_build import to_pyg


class DSAData(InMemoryDataset):
    def __init__(self, samples):
        super().__init__(None)
        data_list = [to_pyg(s) for s in samples]
        self.data, self.slices = self.collate(data_list)


def load_samples(path):
    with open(path, "rb") as f:
        return pickle.load(f)["samples"]


def id_ood_split_by_dispatch(samples, ood_quantile=0.8, seed=0):
    """In-distribution = lower dispatch penetration; OOD = the highest-penetration
    tail held out entirely (Setting 1)."""
    rho = np.array([s["rho_disp"] for s in samples])
    thr = np.quantile(rho, ood_quantile)
    id_idx = np.where(rho <= thr)[0]
    ood_idx = np.where(rho > thr)[0]
    # group the in-distribution part by operating condition before splitting
    groups = {}
    for i in id_idx:
        groups.setdefault(samples[i].get("scenario_id", i), []).append(i)
    keys = sorted(groups)
    rng = np.random.default_rng(seed)
    rng.shuffle(keys)
    n_val = max(1, int(0.15 * len(keys)))
    val_idx = [i for k in keys[:n_val] for i in groups[k]]
    train_idx = [i for k in keys[n_val:] for i in groups[k]]
    pick = lambda I: [samples[i] for i in I]
    return pick(train_idx), pick(val_idx), pick(ood_idx)


def random_split(samples, fracs=(0.7, 0.15, 0.15), seed=0):
    """Split by OPERATING CONDITION, not by sample.

    Every contingency applied to one operating point shares that point's
    pre-fault state, so splitting individual samples would place near-identical
    inputs on both sides of the split and inflate the reported test scores.
    Grouping by scenario_id keeps each operating point wholly within one split.
    """
    groups = {}
    for i, s in enumerate(samples):
        groups.setdefault(s.get("scenario_id", i), []).append(i)
    keys = sorted(groups)
    rng = np.random.default_rng(seed)
    rng.shuffle(keys)
    n = len(keys)
    a = int(fracs[0] * n)
    b = a + int(fracs[1] * n)
    def pick(ks):
        out = []
        for k in ks:
            out.extend(samples[i] for i in groups[k])
        return out
    return pick(keys[:a]), pick(keys[a:b]), pick(keys[b:])


def group_split_by_rho_cap(samples, train_max=0.5, test_min=0.7):
    """Capacity-shift OOD: train on low installed penetration, test on high."""
    tr = [s for s in samples if s["rho_cap"] <= train_max + 1e-9]
    te = [s for s in samples if s["rho_cap"] >= test_min - 1e-9]
    groups = {}
    for i, s in enumerate(tr):
        groups.setdefault(s.get("scenario_id", i), []).append(i)
    keys = sorted(groups)
    rng = np.random.default_rng(0)
    rng.shuffle(keys)
    n_val = max(1, int(0.15 * len(keys)))
    val = [tr[i] for k in keys[:n_val] for i in groups[k]]
    trn = [tr[i] for k in keys[n_val:] for i in groups[k]]
    return trn, val, te


NODE_BASE = list(range(13))          # pre-fault node features
NODE_CONT = {"is_fault": 13, "is_trip": 14, "t_clear": 15, "hops": 16}
EDGE_BASE = list(range(4))           # pre-fault edge features; col 4 = is_tripped

VARIANTS = {
    # name: (extra node columns, keep tripped-edge flag)
    "aware": (["is_fault", "is_trip", "t_clear", "hops"], True),
    "blind": ([], False),
    "loc":   (["is_fault", "is_trip", "hops"], True),     # location, no timing
    "tc":    (["t_clear"], False),                        # timing, no location
}


def select_features(samples, variant):
    """Return copies of samples restricted to the features of `variant`.

    'blind' keeps only the pre-fault description of the operating point, which
    is what a model sees when the contingency is not part of its input."""
    extra, edge_flag = VARIANTS[variant]
    ncols = NODE_BASE + [NODE_CONT[c] for c in extra]
    ecols = EDGE_BASE + ([4] if edge_flag else [])
    out = []
    for s in samples:
        g = dict(s["graph"])
        g["fmask"] = (g["x"][:, NODE_CONT["is_fault"]].astype(np.float32)
                      if "is_fault" in extra else np.zeros(g["x"].shape[0], np.float32))
        g["x"] = np.ascontiguousarray(g["x"][:, ncols])
        g["edge_attr"] = np.ascontiguousarray(g["edge_attr"][:, ecols])
        t = dict(s); t["graph"] = g
        out.append(t)
    return out


def _binary_cols(M):
    return [c for c in range(M.shape[1]) if np.isin(np.unique(M[:, c]), [0.0, 1.0]).all()]


def fit_scaler(train_samples):
    """Per-feature mean/std over the TRAINING split only.

    Binary indicator columns (node-type one-hot, generator flag, contingency
    flags) are left unscaled. Fitting on the pooled dataset would leak the
    held-out distribution into training, so statistics come from training data
    alone and are then applied unchanged to validation and test data.
    """
    X = np.concatenate([s["graph"]["x"] for s in train_samples], axis=0)
    binx = set(_binary_cols(X))
    cols = [c for c in range(X.shape[1]) if c not in binx]
    mu = np.zeros(X.shape[1], dtype=np.float32)
    sd = np.ones(X.shape[1], dtype=np.float32)
    mu[cols] = X[:, cols].mean(0)
    sd[cols] = X[:, cols].std(0) + 1e-6
    E = np.concatenate([s["graph"]["edge_attr"] for s in train_samples], axis=0)
    bine = set(_binary_cols(E))
    emu = np.zeros(E.shape[1], dtype=np.float32)
    esd = np.ones(E.shape[1], dtype=np.float32)
    ec = [c for c in range(E.shape[1]) if c not in bine]
    emu[ec] = E[:, ec].mean(0)
    esd[ec] = E[:, ec].std(0) + 1e-6
    return dict(mu=mu, sd=sd, emu=emu, esd=esd)


def apply_scaler(samples, sc):
    out = []
    for s in samples:
        g = dict(s["graph"])
        g["x_raw"] = g["x"]          # unscaled copy, in physical units
        g["x"] = ((g["x"] - sc["mu"]) / sc["sd"]).astype(np.float32)
        g["edge_attr"] = ((g["edge_attr"] - sc["emu"]) / sc["esd"]).astype(np.float32)
        t = dict(s); t["graph"] = g
        out.append(t)
    return out


def make_loaders(train, val, test, batch_size=32, scale=True):
    if scale and len(train):
        sc = fit_scaler(train)
        train = apply_scaler(train, sc)
        val = apply_scaler(val, sc) if val else val
        test = apply_scaler(test, sc) if test else test
    def mk(s, shuffle):
        return DataLoader(DSAData(s), batch_size=batch_size, shuffle=shuffle) \
            if len(s) else None
    return mk(train, True), mk(val, False), mk(test, False)
