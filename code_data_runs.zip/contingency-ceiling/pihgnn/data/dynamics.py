"""Positive-sequence (RMS) transient-stability simulator with heterogeneous
generation: synchronous generators, grid-forming (GFM/VSM) and grid-following
(GFL/PLL) inverter-based resources.

Modelling scope:
  * SGs: classical constant-voltage-behind-transient-reactance model with swing
    dynamics and damping (Norton current source behind X'd).
  * GFM: virtual-synchronous-machine swing-like angle/frequency model behind a
    filter reactance (Norton source behind Xf).
  * GFL: current-controlled source injecting at a PLL-tracked angle, with a
    damped second-order PLL and a hard current limit. Because it is a current
    source, no shunt is folded into Ybus for GFL buses.
  * The network is solved algebraically each step (quasi-steady-state phasor).
    Sub-transient / EMT phenomena are NOT represented.

Self-contained; the replica of the public 9-bus benchmark (bench9/) uses ANDES
with detailed machine, exciter and stabiliser models instead.
"""
from __future__ import annotations
import numpy as np
from scipy.linalg import lu_factor, lu_solve

OMEGA_S = 2 * np.pi * 60.0
F0 = 60.0


class Network:
    def __init__(self, case, ybus, devices):
        self.case = case
        self.nb = case["bus"].shape[0]
        self.baseMVA = case["baseMVA"]
        self.bus_ids = case["bus"][:, 0].astype(int)
        self.bidx = {b: i for i, b in enumerate(self.bus_ids)}
        self.Y0 = ybus.copy()
        self.devices = devices
        self.dev_bus = sorted(devices.keys())
        self.dev_list = [devices[b] for b in self.dev_bus]
        self.xsrc = {b: d.get("Xdp", d.get("Xf", 0.1))
                     for b, d in devices.items()}
        self.Ybase = self.Y0.copy()
        for b, d in devices.items():
            if d["type"] in ("SG", "GFM"):
                self.Ybase[self.bidx[b], self.bidx[b]] += 1.0 / (1j * self.xsrc[b])

    def solve(self, lu, inj):
        if not np.isfinite(inj).all():
            return np.full(self.nb, np.nan, dtype=complex)
        return lu_solve(lu, inj, check_finite=False)


def _add_loads(Ybase, case, baseMVA, V):
    Y = Ybase.copy()
    for k, b in enumerate(case["bus"]):
        Pd, Qd = b[2] / baseMVA, b[3] / baseMVA
        if Pd != 0 or Qd != 0:
            Y[k, k] += np.conj(Pd + 1j * Qd) / (abs(V[k]) ** 2 + 1e-9)
    return Y


def _run_powerflow(net):
    try:
        if not hasattr(np, "in1d"):
            np.in1d = np.isin  # numpy>=2 compat for PYPOWER
        from pypower.api import runpf, ppoption
        res, ok = runpf(net.case, ppoption(VERBOSE=0, OUT_ALL=0, PF_MAX_IT=30))
        if not ok:
            raise RuntimeError("PF did not converge")
        bus, gen = res["bus"], res["gen"]
        V = bus[:, 7] * np.exp(1j * np.deg2rad(bus[:, 8]))
        Pg = {int(g[0]): g[1] / net.baseMVA for g in gen}
        Qg = {int(g[0]): g[2] / net.baseMVA for g in gen}
        return V, Pg, Qg
    except Exception:
        bus, gen = net.case["bus"], net.case["gen"]
        V = bus[:, 7] * np.exp(1j * np.deg2rad(bus[:, 8]))
        Pg = {int(g[0]): g[1] / net.baseMVA for g in gen}
        Qg = {int(g[0]): g[2] / net.baseMVA for g in gen}
        return V, Pg, Qg


def initialise(net):
    """Initialise all device states from the converged power flow so the
    pre-fault trajectory is a true equilibrium."""
    V, Pg, Qg = _run_powerflow(net)
    net.Vpf = V
    net.Yload = _add_loads(net.Ybase, net.case, net.baseMVA, V)
    states, layout = [], []
    net.Emag, net.Pset, net.Imag, net.Iphi = {}, {}, {}, {}
    ptr = 0
    for b in net.dev_bus:
        d = net.devices[b]
        k = net.bidx[b]
        vt = V[k]
        x = net.xsrc[b]
        P, Q = Pg.get(b, 0.5), Qg.get(b, 0.0)
        It = np.conj((P + 1j * Q) / (vt + 1e-9))
        if d["type"] in ("SG", "GFM"):
            Eint = vt + 1j * x * It
            states += [float(np.angle(Eint)), 0.0]
            net.Emag[b] = float(abs(Eint))
            net.Pset[b] = P
        else:  # GFL current source with PLL
            states += [float(np.angle(vt)), 0.0]
            net.Imag[b] = float(abs(It))
            net.Iphi[b] = float(np.angle(It) - np.angle(vt))
            net.Pset[b] = P
        layout.append((b, d["type"], slice(ptr, ptr + 2)))
        ptr += 2
    return np.array(states, dtype=float), layout


def _network_solution(net, y, layout, lu):
    inj = np.zeros(net.nb, dtype=complex)
    for (b, dtype, sl) in layout:
        k = net.bidx[b]
        ang = y[sl.start]
        if dtype in ("SG", "GFM"):
            inj[k] += net.Emag[b] * np.exp(1j * ang) / (1j * net.xsrc[b])
        else:
            Imax = net.devices[b].get("Imax", 1.2) * net.Imag[b]
            Icmd = min(net.Imag[b], Imax)
            inj[k] += Icmd * np.exp(1j * (ang + net.Iphi[b]))
    V = net.solve(lu, inj)
    P = {}
    for (b, dtype, sl) in layout:
        k = net.bidx[b]
        ang = y[sl.start]
        if dtype in ("SG", "GFM"):
            Ei = net.Emag[b] * np.exp(1j * ang)
            Ii = (Ei - V[k]) / (1j * net.xsrc[b])
            P[b] = float((Ei * np.conj(Ii)).real)
        else:
            Ii = net.Imag[b] * np.exp(1j * (ang + net.Iphi[b]))
            P[b] = float((V[k] * np.conj(Ii)).real)
    return V, P


def rhs(t, y, net, layout, lu):
    dydt = np.zeros_like(y)
    V, P = _network_solution(net, y, layout, lu)
    for (b, dtype, sl) in layout:
        d = net.devices[b]
        i0 = sl.start
        ang, dw = y[i0], y[i0 + 1]
        if dtype == "SG":
            H, D = d["H"], d["D"]
            dydt[i0] = dw * OMEGA_S
            dydt[i0 + 1] = (net.Pset[b] - P[b] - D * dw) / (2 * H)
        elif dtype == "GFM":
            J, Dp = d["J"], d["Dp"]
            dydt[i0] = dw * OMEGA_S
            dydt[i0 + 1] = (net.Pset[b] - P[b] - Dp * dw) / (2 * J)
        else:
            k = net.bidx[b]
            tau, Kp = d["tau_pll"], d["Kp_pll"]
            # PLL holds (freezes) during deep voltage sags -- a standard
            # ride-through behaviour; the angle cannot be tracked at ~0 voltage.
            if abs(V[k]) < 0.25:
                ang_err = 0.0
            else:
                ang_err = np.angle(np.exp(1j * (np.angle(V[k]) - ang)))
            dydt[i0] = dw * OMEGA_S
            dydt[i0 + 1] = (Kp * ang_err - dw) / tau
    return dydt


def _fault_ybus(net, fault_bus, rf=1e-4):
    Yf = net.Yload.copy()
    Yf[net.bidx[fault_bus], net.bidx[fault_bus]] += 1.0 / rf
    return Yf


def _postfault_ybus(net, trip_branch):
    if trip_branch is None:
        return net.Yload.copy()
    case = dict(net.case)
    br = case["branch"].copy()
    if 0 <= trip_branch < br.shape[0]:
        br[trip_branch, 10] = 0.0
    case["branch"] = br
    from .case39 import build_ybus
    Y = build_ybus(case)
    for b, d in net.devices.items():
        if d["type"] in ("SG", "GFM"):
            Y[net.bidx[b], net.bidx[b]] += 1.0 / (1j * net.xsrc[b])
    return _add_loads(Y, net.case, net.baseMVA, net.Vpf)


def _rk4(net, layout, lu, y0, t0, t1, dt):
    """Fixed-step RK4 integration of the device ODEs over [t0, t1]."""
    n = max(1, int(round((t1 - t0) / dt)))
    h = (t1 - t0) / n
    ts = np.empty(n + 1)
    Ys = np.empty((y0.size, n + 1))
    ts[0], Ys[:, 0] = t0, y0
    y = y0.copy()
    t = t0
    for i in range(1, n + 1):
        k1 = rhs(t, y, net, layout, lu)
        k2 = rhs(t + 0.5 * h, y + 0.5 * h * k1, net, layout, lu)
        k3 = rhs(t + 0.5 * h, y + 0.5 * h * k2, net, layout, lu)
        k4 = rhs(t + h, y + h * k3, net, layout, lu)
        y = y + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        if not np.isfinite(y).all():
            ts[i:] = t + h
            Ys[:, i:] = y[:, None]
            break
        t += h
        ts[i], Ys[:, i] = t, y
    return ts, Ys


def simulate(net, y0, layout, fault_bus, trip_branch, t_clear,
             t_end=10.0, dt=0.005):
    """Fault-on / fault-cleared simulation via fixed-step RK4 with per-phase LU
    factorization of the (constant) network matrices for speed."""
    reg = 1e-6 * np.eye(net.nb)     # regularize against isolated-bus singularity
    lu_f = lu_factor(_fault_ybus(net, fault_bus) + reg)
    lu_p = lu_factor(_postfault_ybus(net, trip_branch) + reg)
    if t_clear > 1e-6:
        t1, Y1 = _rk4(net, layout, lu_f, y0, 0.0, t_clear, min(dt, t_clear))
        yc, tc = Y1[:, -1], t1[-1]
    else:
        t1, Y1, yc, tc = np.array([0.0]), y0.reshape(-1, 1), y0, 0.0
    t2, Y2 = _rk4(net, layout, lu_p, yc, tc, t_end, dt)
    return np.concatenate([t1, t2[1:]]), np.concatenate([Y1, Y2[:, 1:]], axis=1)


def stability_diagnostics(net, layout, t, Y, t_eval_from=0.0, settle=0.05):
    """Return the raw margins that the stability criterion thresholds.

    Recording these at generation time makes the threshold sensitivity study
    possible without storing full trajectories or re-running any time-domain
    simulation: relabelling at a different angle limit becomes a comparison
    against a stored scalar.
    """
    out = dict(max_coi_angle_deg=float("inf"), freq_nadir_hz=float("inf"),
               max_rocof_hz_s=float("inf"), diverged=True)
    mask = t >= t_eval_from + settle
    if mask.sum() < 5:
        mask = t >= t_eval_from
    t, Y = t[mask], Y[:, mask]
    if t.size < 3 or not np.all(np.isfinite(Y)):
        return out
    sgm = [(b, sl.start) for (b, dt_, sl) in layout if dt_ in ("SG", "GFM")]
    gfl = [sl.start for (b, dt_, sl) in layout if dt_ == "GFL"]
    out["pll_max_dev_hz"] = 0.0
    out["pll_end_dev_hz"] = 0.0
    if not sgm:
        out["diverged"] = False
        return out
    Hs = np.array([net.devices[b].get("H", net.devices[b].get("J", 3.0))
                   for (b, _) in sgm])
    angs = np.array([Y[i] for (_, i) in sgm])
    ws = np.array([Y[i + 1] for (_, i) in sgm])
    if not np.isfinite(angs).all() or not np.isfinite(ws).all():
        return out
    out["diverged"] = False
    coi = (Hs[:, None] * angs).sum(0) / Hs.sum()
    out["max_coi_angle_deg"] = float(np.rad2deg(np.abs(angs - coi[None, :])).max())
    coif = (Hs[:, None] * ws).sum(0) / Hs.sum() * F0
    out["freq_nadir_hz"] = float(np.abs(coif).max())
    if gfl:
        pll = np.array([Y[i + 1] for i in gfl]) * F0          # Hz deviation
        dev = np.abs(pll - coif[None, :])
        tail = t >= t[-1] - 0.5
        out["pll_max_dev_hz"] = float(dev.max())
        out["pll_end_dev_hz"] = float(dev[:, tail].mean(1).max())
    dt = t[1] - t[0]
    win = max(1, int(round(0.1 / (dt + 1e-9))))
    if coif.size > win:
        out["max_rocof_hz_s"] = float((np.abs(coif[win:] - coif[:-win]) / (win * dt)).max())
    else:
        out["max_rocof_hz_s"] = 0.0
    return out


def stability_label(net, layout, t, Y, t_eval_from=0.0, settle=0.05,
                    angle_limit_deg=180.0, nadir_hz=2.5, rocof_limit=2.0):
    """Composite IBR-aware stability criterion:

      (1) Transient angle stability: maximum machine angle relative to the
          inertia-weighted centre of inertia (COI) must stay below
          `angle_limit_deg` (classical first-swing threshold, 180 deg).
      (2) Frequency security: COI frequency-deviation nadir within `nadir_hz`.
      (3) RoCoF security: COI RoCoF (100 ms window) within `rocof_limit`.

    Evaluated on the post-fault window, skipping a short `settle` interval after
    clearing to avoid the switching transient. Returns 1 (stable) / 0 (unstable).
    """
    mask = t >= t_eval_from + settle
    if mask.sum() < 5:
        mask = t >= t_eval_from
    t, Y = t[mask], Y[:, mask]
    if t.size < 3:
        return 0

    sgm = [(b, sl.start) for (b, dt, sl) in layout if dt in ("SG", "GFM")]
    if sgm:
        Hs = np.array([net.devices[b].get("H", net.devices[b].get("J", 3.0))
                       for (b, _) in sgm])
        angs = np.array([Y[i] for (_, i) in sgm])          # (m, T)
        ws = np.array([Y[i + 1] for (_, i) in sgm])        # (m, T)
        if not np.isfinite(angs).all() or not np.isfinite(ws).all():
            return 0
        coi = (Hs[:, None] * angs).sum(0) / Hs.sum()
        rel = np.rad2deg(np.abs(angs - coi[None, :]))
        if rel.max() > angle_limit_deg:                    # (1) angle
            return 0
        coif = (Hs[:, None] * ws).sum(0) / Hs.sum() * F0
        if np.abs(coif).max() > nadir_hz:                  # (2) frequency
            return 0
        dt = t[1] - t[0]
        win = max(1, int(round(0.1 / (dt + 1e-9))))
        if coif.size > win:                                # (3) RoCoF (windowed)
            rocof = np.abs(coif[win:] - coif[:-win]) / (win * dt)
            if rocof.max() > rocof_limit:
                return 0
    return 1


DT = 0.01   # integration step (s); see step-halving check in the paper


def _label_for_clear(net, y0, layout, fault_bus, trip_branch, t_clear,
                     t_end=4.0):
    t, Y = simulate(net, y0, layout, fault_bus, trip_branch,
                    t_clear=t_clear, t_end=t_end, dt=DT)
    return stability_label(net, layout, t, Y, t_eval_from=t_clear)


def label_and_diagnostics(net, y0, layout, fault_bus, trip_branch, t_clear,
                          t_end=4.0, dt=None):
    """One simulation; returns (label, margins) so that relabelling under other
    criteria needs no further simulation."""
    t, Y = simulate(net, y0, layout, fault_bus, trip_branch,
                    t_clear=t_clear, t_end=t_end, dt=dt or DT)
    lab = stability_label(net, layout, t, Y, t_eval_from=t_clear)
    diag = stability_diagnostics(net, layout, t, Y, t_eval_from=t_clear)
    return lab, diag


def critical_clearing_time(net, y0, layout, fault_bus, trip_branch,
                           t_lo=0.0, t_hi=0.5, tol=1e-3):
    if _label_for_clear(net, y0, layout, fault_bus, trip_branch, t_hi) == 1:
        return t_hi
    if _label_for_clear(net, y0, layout, fault_bus, trip_branch, t_lo) == 0:
        return t_lo
    while t_hi - t_lo > tol:
        mid = 0.5 * (t_lo + t_hi)
        if _label_for_clear(net, y0, layout, fault_bus, trip_branch, mid) == 1:
            t_lo = mid
        else:
            t_hi = mid
    return t_lo
