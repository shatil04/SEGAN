"""IEEE 39-bus case loader and IBR-penetration configuration.

Static network data are the verified MATPOWER/PYPOWER `case39` (New England),
bundled as `case39.json`. Classical machine dynamic data (H, Xdp, D) are the
standard Athay et al. (1979) values used throughout the transient-stability
literature. Nothing here is fabricated; it is public-domain test-system data.
"""
from __future__ import annotations
import json
import os
import numpy as np

_HERE = os.path.dirname(__file__)

# Standard IEEE 39-bus classical dynamic data (100 MVA base).
# Keys are generator bus numbers. H [s], Xdp [pu], D [pu]. (Athay 1979 / Pai.)
GEN_DYN = {
    30: dict(H=42.0, Xdp=0.031, D=4.0),
    31: dict(H=30.3, Xdp=0.0697, D=9.75),
    32: dict(H=35.8, Xdp=0.0531, D=10.0),
    33: dict(H=28.6, Xdp=0.0436, D=10.0),
    34: dict(H=26.0, Xdp=0.132, D=3.0),
    35: dict(H=34.8, Xdp=0.050, D=10.0),
    36: dict(H=26.4, Xdp=0.049, D=8.0),
    37: dict(H=24.3, Xdp=0.057, D=9.0),
    38: dict(H=34.5, Xdp=0.057, D=14.0),
    39: dict(H=500.0, Xdp=0.006, D=100.0),  # aggregate equivalent machine
}


def load_case39() -> dict:
    """Return the bundled case39 as numpy arrays."""
    with open(os.path.join(_HERE, "case39.json")) as f:
        raw = json.load(f)
    case = {}
    for k, v in raw.items():
        case[k] = np.asarray(v, dtype=float) if isinstance(v, list) else v
    return case


def build_ybus(case: dict) -> np.ndarray:
    """Construct the bus admittance matrix Ybus from branch data."""
    bus = case["bus"]
    branch = case["branch"]
    nb = bus.shape[0]
    # bus id -> index
    bus_ids = bus[:, 0].astype(int)
    idx = {b: i for i, b in enumerate(bus_ids)}
    Y = np.zeros((nb, nb), dtype=complex)
    for br in branch:
        f, t = int(br[0]), int(br[1])
        r, x, b = br[2], br[3], br[4]
        status = br[10]
        if status == 0:
            continue
        tap = br[8] if br[8] != 0 else 1.0
        shift = np.deg2rad(br[9])
        ys = 1.0 / (r + 1j * x)
        bc = 1j * b / 2.0
        i, j = idx[f], idx[t]
        tapc = tap * np.exp(1j * shift)
        Y[i, i] += (ys + bc) / (tap ** 2)
        Y[j, j] += ys + bc
        Y[i, j] += -ys / np.conj(tapc)
        Y[j, i] += -ys / tapc
    # bus shunts
    for k, b in enumerate(bus):
        gs, bs = b[4], b[5]
        Y[k, k] += (gs + 1j * bs) / case["baseMVA"]
    return Y


def make_penetration_config(case: dict, rho_cap: float, gfm_gfl_ratio=(1, 2),
                            rng: np.random.Generator | None = None,
                            gen_dyn: dict | None = None,
                            exclude: set | None = None) -> dict:
    """Replace a subset of SGs by IBRs to reach installed-capacity penetration
    rho_cap (fraction of generation capacity that is inverter-based).

    Returns a device table classifying each generator bus as 'SG', 'GFM' or
    'GFL', along with per-device parameters. The GFM:GFL split follows the given
    ratio. Deterministic given `rng`.
    """
    if rng is None:
        rng = np.random.default_rng(0)
    if gen_dyn is None:
        gen_dyn = GEN_DYN
    if exclude is None:
        exclude = {39}
    gen = case["gen"]
    gen_buses = gen[:, 0].astype(int).tolist()
    caps = gen[:, 8].copy()  # PMAX (MW): installed capacity
    total_cap = caps.sum()

    # Greedily convert machines (excluding external-area equivalents) until the
    # converted share of installed capacity reaches rho_cap.
    order = [b for b in gen_buses if b not in exclude]
    rng.shuffle(order)
    converted, conv_cap = [], 0.0
    for b in order:
        if conv_cap / total_cap >= rho_cap:
            break
        converted.append(b)
        conv_cap += caps[gen_buses.index(b)]

    # Split converted machines into GFM / GFL by the requested ratio.
    ngfm = max(1, int(round(len(converted) * gfm_gfl_ratio[0] /
                            sum(gfm_gfl_ratio)))) if converted else 0
    gfm_set = set(converted[:ngfm])
    gfl_set = set(converted[ngfm:])

    devices = {}
    for b in gen_buses:
        if b in gfm_set:
            dtype = "GFM"
        elif b in gfl_set:
            dtype = "GFL"
        else:
            dtype = "SG"
        devices[b] = _device_params(b, dtype, rng, gen_dyn)
    return dict(devices=devices, rho_cap=rho_cap,
                converted=converted, gfm=sorted(gfm_set), gfl=sorted(gfl_set))


def _device_params(bus: int, dtype: str, rng: np.random.Generator,
                   gen_dyn: dict | None = None) -> dict:
    """Per-device dynamic parameters. IBR parameters are sampled within
    literature-typical ranges; SGs use the standard classical data."""
    if dtype == "SG":
        d = dict((gen_dyn or GEN_DYN)[bus])
        d["type"] = "SG"
        return d
    if dtype == "GFM":
        # Virtual synchronous machine: J (virtual inertia, s), Dp droop, Xf.
        return dict(type="GFM",
                    J=float(rng.uniform(2.0, 8.0)),      # lower than SG inertia
                    Dp=float(rng.uniform(20.0, 60.0)),
                    Xf=float(rng.uniform(0.05, 0.15)),
                    Imax=float(rng.uniform(1.1, 1.3)),   # pu of rating
                    Smax=float(rng.uniform(1.0, 2.5)))
    # GFL: PLL + current control. Represented by PLL bandwidth and current limit.
    # PLL gains give closed-loop natural frequencies of about 2.5-9 Hz, the
    # range appropriate to positive-sequence (RMS) converter models.
    return dict(type="GFL",
                tau_pll=float(rng.uniform(0.05, 0.12)),
                Kp_pll=float(rng.uniform(0.08, 0.40)),
                Xf=float(rng.uniform(0.05, 0.15)),
                Imax=float(rng.uniform(1.1, 1.2)),
                SCR=float(rng.uniform(1.5, 5.0)))
