"""Test-system registry.

Each system provides MATPOWER-format static data (bus/branch/gen arrays) plus
classical machine data keyed by generator bus, so that the same simulator,
penetration logic and graph builder serve every system.

  ieee39  IEEE 39-bus New England. Static data: MATPOWER case39. Machine data:
          Athay et al. (1979), 100 MVA base.
  npcc    NPCC 140-bus, 48-machine model as distributed with the open-source
          ANDES package. Static data and machine data (inertia, transient
          reactance, ratings) are read from the ANDES case files and converted
          to a 100 MVA system base. Machines sharing a bus are aggregated.
  wscc9   WSCC 3-machine, 9-bus system. Static data from the ANDES case files;
          machine data are the standard values of Anderson and Fouad.
"""
from __future__ import annotations
import os
import numpy as np

SBASE = 100.0


def _empty_case(nb, nl, ng):
    return dict(baseMVA=SBASE, bus=np.zeros((nb, 13)), branch=np.zeros((nl, 13)),
                gen=np.zeros((ng, 21)), version="2")


def _from_andes(path, damping_ratio=0.2):
    """Build a MATPOWER-style case and per-bus classical data from an ANDES case."""
    import andes
    andes.config_logger(stream_level=50)
    ss = andes.load(path, setup=True, no_output=True, default_config=True)
    if not ss.PFlow.run():
        raise RuntimeError(f"ANDES power flow failed for {path}")

    bus_idx = list(ss.Bus.idx.v)
    pos = {b: i for i, b in enumerate(bus_idx)}
    nb = len(bus_idx)

    # static generators (PV + Slack)
    gens = []
    for mdl in (ss.Slack, ss.PV):
        for k in range(mdl.n):
            gens.append(dict(idx=mdl.idx.v[k], bus=mdl.bus.v[k],
                             p=float(mdl.p.v[k]), q=float(mdl.q.v[k]),
                             v0=float(mdl.v0.v[k]),
                             slack=(mdl is ss.Slack)))
    nl = ss.Line.n
    case = _empty_case(nb, nl, 0)
    bus = case["bus"]
    for i, b in enumerate(bus_idx):
        bus[i, 0] = i + 1                      # renumber 1..nb
        bus[i, 1] = 1
        bus[i, 7] = float(ss.Bus.v.v[i])
        bus[i, 8] = float(np.rad2deg(ss.Bus.a.v[i]))
        bus[i, 9] = float(ss.Bus.Vn.v[i])
        bus[i, 6] = bus[i, 10] = 1
        bus[i, 11], bus[i, 12] = 1.1, 0.9
    for k in range(ss.PQ.n):
        i = pos[ss.PQ.bus.v[k]]
        bus[i, 2] += float(ss.PQ.p0.v[k]) * SBASE
        bus[i, 3] += float(ss.PQ.q0.v[k]) * SBASE
    for k in range(ss.Shunt.n):
        i = pos[ss.Shunt.bus.v[k]]
        bus[i, 4] += float(ss.Shunt.g.v[k]) * SBASE
        bus[i, 5] += float(ss.Shunt.b.v[k]) * SBASE

    br = case["branch"]
    L = ss.Line
    for k in range(nl):
        br[k, 0] = pos[L.bus1.v[k]] + 1
        br[k, 1] = pos[L.bus2.v[k]] + 1
        br[k, 2], br[k, 3], br[k, 4] = L.r.v[k], L.x.v[k], L.b.v[k]
        tap = float(L.tap.v[k])
        br[k, 8] = 0.0 if abs(tap - 1.0) < 1e-12 else tap
        br[k, 9] = float(np.rad2deg(L.phi.v[k]))
        br[k, 10] = float(L.u.v[k])
        br[k, 11], br[k, 12] = -360, 360

    # aggregate generators per bus
    per_bus = {}
    for g in gens:
        i = pos[g["bus"]]
        e = per_bus.setdefault(i, dict(p=0.0, q=0.0, v0=g["v0"], slack=False,
                                       H=0.0, ysrc=0.0, S=0.0))
        e["p"] += g["p"]
        e["q"] += g["q"]
        e["slack"] |= g["slack"]
    # machine data: GENROU and GENCLS reference static gens via `gen`
    gpos = {g["idx"]: pos[g["bus"]] for g in gens}
    for mdl in (ss.GENROU, ss.GENCLS):
        for k in range(mdl.n):
            i = gpos[mdl.gen.v[k]]
            Sn = float(mdl.Sn.v[k])
            H_sys = 0.5 * float(mdl.M.v[k]) * Sn / SBASE
            xd1_sys = float(mdl.xd1.v[k]) * SBASE / Sn
            e = per_bus[i]
            e["H"] += H_sys
            e["ysrc"] += 1.0 / xd1_sys          # parallel reactances
            e["S"] += Sn

    gen = np.zeros((len(per_bus), 21))
    gen_dyn = {}
    for r, (i, e) in enumerate(sorted(per_bus.items())):
        busno = i + 1
        bus[i, 1] = 3 if e["slack"] else 2
        gen[r, 0] = busno
        gen[r, 1] = e["p"] * SBASE
        gen[r, 2] = e["q"] * SBASE
        gen[r, 3], gen[r, 4] = 9999.0, -9999.0
        gen[r, 5] = e["v0"]
        gen[r, 6] = SBASE
        gen[r, 7] = 1
        gen[r, 8] = max(e["S"], abs(e["p"]) * SBASE * 1.1)
        if e["H"] <= 0:                          # static gen without dynamics
            e["H"], e["ysrc"] = 5.0 * max(e["S"], 100.0) / SBASE, 1 / 0.3
        H = e["H"]
        gen_dyn[busno] = dict(H=float(H), Xdp=float(1.0 / e["ysrc"]),
                              D=float(damping_ratio * H))
    case["gen"] = gen
    return case, gen_dyn


def get_system(name: str):
    """Return dict(case, gen_dyn, exclude) for a named system."""
    if name == "ieee39":
        from .case39 import load_case39, GEN_DYN
        return dict(case=load_case39(), gen_dyn=GEN_DYN, exclude={39})
    import andes
    root = os.path.join(os.path.dirname(andes.__file__), "cases")
    if name == "npcc":
        case, gd = _from_andes(os.path.join(root, "npcc", "npcc.xlsx"))
        # very large-inertia machines are external-area equivalents; keep them
        # synchronous, as bus 39 is kept synchronous in the 39-bus system
        Hs = np.array([d["H"] for d in gd.values()])
        thr = np.quantile(Hs, 0.9)
        exclude = {b for b, d in gd.items() if d["H"] >= thr}
        return dict(case=case, gen_dyn=gd, exclude=exclude)
    if name == "wscc9":
        case, _ = _from_andes(os.path.join(root, "wscc9", "wscc9.xlsx"))
        # Anderson & Fouad, 100 MVA base
        af = [dict(H=23.64, Xdp=0.0608, D=2.364),
              dict(H=6.40, Xdp=0.1198, D=0.640),
              dict(H=3.01, Xdp=0.1813, D=0.301)]
        gbuses = sorted(int(b) for b in case["gen"][:, 0])
        # order machines by dispatch, largest first, matching the A&F numbering
        order = sorted(gbuses, key=lambda b: -case["gen"][
            list(case["gen"][:, 0].astype(int)).index(b), 1])
        if case["bus"][int(order[0]) - 1, 1] != 3:
            slack = [int(b) for b in gbuses if case["bus"][b - 1, 1] == 3]
            order = slack + [b for b in order if b not in slack]
        gd = {b: af[k] for k, b in enumerate(order)}
        return dict(case=case, gen_dyn=gd, exclude=set())
    raise ValueError(name)
