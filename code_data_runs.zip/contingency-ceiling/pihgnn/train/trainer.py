"""Training loop: cross-entropy classification, plus a smooth-L1 term on the
critical clearing time when the model has a CCT head and CCT labels exist.
AdamW with a cosine learning-rate schedule; the checkpoint with the best
validation accuracy is kept (early stopping on validation accuracy)."""
from __future__ import annotations
import copy
import numpy as np
import torch
import torch.nn.functional as F

from .metrics import classification_metrics


def train_model(model, loaders, device="cpu", epochs=100, lr=1e-3,
                weight_decay=1e-4, patience=20, beta=1.0, verbose=False):
    train_loader, val_loader, _ = loaders
    model = model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    best_val, best_state, wait, hist = -1.0, None, 0, []
    for ep in range(epochs):
        model.train()
        for batch in train_loader:
            batch = batch.to(device)
            opt.zero_grad()
            out = model(batch)
            loss = F.cross_entropy(out[0], batch.y.view(-1))
            if beta > 0 and len(out) > 3 and hasattr(batch, "cct"):
                loss = loss + beta * F.smooth_l1_loss(out[3].view(-1), batch.cct.view(-1))
            loss.backward()
            opt.step()
        sched.step()
        val = evaluate(model, val_loader, device) if val_loader else {"acc": 0}
        hist.append(val)
        if val["acc"] > best_val:
            best_val, best_state, wait = val["acc"], copy.deepcopy(model.state_dict()), 0
        else:
            wait += 1
            if wait >= patience:
                break
        if verbose and ep % 10 == 0:
            print(f"  epoch {ep}: val_acc={val['acc']:.3f}")
    if best_state is not None:
        model.load_state_dict(best_state)
    return model, hist


@torch.no_grad()
def evaluate(model, loader, device="cpu"):
    if loader is None:
        return {"acc": float("nan")}
    model.eval()
    ys, ps = [], []
    for batch in loader:
        batch = batch.to(device)
        prob = torch.softmax(model(batch)[0], dim=-1)[:, 1]  # P(stable)
        ys.append(batch.y.view(-1).cpu().numpy())
        ps.append(prob.cpu().numpy())
    y, p = np.concatenate(ys), np.concatenate(ps)
    m = classification_metrics(y, p)
    m["_y"], m["_p"] = y, p
    return m
