"""Evaluation metrics: accuracy, F1, AUC and false-negative rate for
classification; calibration error; CCT MAE / RMSE."""
from __future__ import annotations
import numpy as np
from sklearn.metrics import f1_score, roc_auc_score, accuracy_score


def classification_metrics(y_true, y_prob):
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    y_pred = (y_prob >= 0.5).astype(int)
    out = dict(
        acc=float(accuracy_score(y_true, y_pred)),
        f1=float(f1_score(y_true, y_pred, zero_division=0)),
    )
    try:
        out["auc"] = float(roc_auc_score(y_true, y_prob))
    except ValueError:
        out["auc"] = float("nan")
    # false-negative rate: fraction of truly unstable cases predicted stable.
    # Here label 1 = stable, 0 = unstable, so a false negative is predicting
    # stable (1) when actually unstable (0).
    unstable = y_true == 0
    if unstable.any():
        out["fnr"] = float((y_pred[unstable] == 1).mean())
    else:
        out["fnr"] = float("nan")
    return out


def expected_calibration_error(y_true, y_prob, n_bins=10):
    """ECE with equal-width probability bins."""
    y_true = np.asarray(y_true)
    y_prob = np.asarray(y_prob)
    bins = np.linspace(0, 1, n_bins + 1)
    ece, table = 0.0, []
    for lo, hi in zip(bins[:-1], bins[1:]):
        m = (y_prob >= lo) & (y_prob < hi if hi < 1 else y_prob <= hi)
        if m.sum() == 0:
            continue
        conf = y_prob[m].mean()
        acc = (y_true[m] == (y_prob[m] >= 0.5)).mean()
        ece += (m.mean()) * abs(acc - conf)
        table.append(dict(lo=float(lo), hi=float(hi), n=int(m.sum()),
                          conf=float(conf), acc=float(acc)))
    return float(ece), table


def cct_metrics(y_true, y_pred):
    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    err = y_pred - y_true
    return dict(mae=float(np.abs(err).mean()),
                rmse=float(np.sqrt((err ** 2).mean())),
                mae_ms=float(np.abs(err).mean() * 1000.0))


def generalisation_gap(id_metric, ood_metric):
    """Difference between in-distribution and out-of-distribution performance
    (e.g. accuracy). Smaller is better; this is the paper's headline quantity."""
    return float(id_metric - ood_metric)
