# Contingency-identifiability ceilings in learning-based DSA

Code, data and run records for "When the contingency is missing: accuracy
ceilings in learning-based dynamic security assessment".

## Layout
- `pihgnn/` - RMS simulator (classical machines, GFM VSM, GFL with PLL) and dataset
  generator (`data/`, islanding trips excluded), models (`models/baselines.py`: MLP,
  GCN, GAT, Het-GNN), training (`train/`) and the experiment driver
  (`experiments/bench2.py`).
- `jobs/` - generation (`gen_job.py`, `queue.txt`), dense Monte-Carlo re-simulation
  (`dense_job.py`), label checks (`validate.py`), dataset merge and converter-aware
  relabelling (`prepare.py`), and the full training queue (`train_queue.txt`).
- `results/data2/` - datasets with stored stability margins (9-bus, 39-bus, 39-bus
  converter-aware labels, NPCC 140-bus) and re-simulation results.
- `results/runs3/` - one JSON record per trained model (system, input variant, model, seed).
- `analysis/` - `analyze3.py` (ceilings, bootstrap intervals, statistics, tables) and
  `figs3.py` (figures), `gain3.py` (gain against headroom) and `knn_ceiling.py`
  (nearest-neighbour ceiling estimates and the aware-feature control).

## Install
    pip install -r requirements.txt

Training is deterministic for a given seed on CPU with `OMP_NUM_THREADS=1`, so
re-running a configuration reproduces its stored run record exactly.

## Reproduce the tables and figures
    python3 analysis/analyze3.py   # writes results/summary3.json and out/tables/
    python3 analysis/figs3.py      # writes out/figs/
    python3 analysis/gain3.py      # gain against headroom (results/gain3.json, out/figs/)
    python3 analysis/knn_ceiling.py  # nearest-neighbour estimates (about 10 min)

## Retrain a model
    OMP_NUM_THREADS=1 RUNS_DIR=results/runs3 python3 -m pihgnn.experiments.bench2 --epochs 40 --seeds 1 \
        --data results/data2/s39.pkl --tag s39 --variants blind,aware --models hetgnn --seed0 0

## Regenerate the data
Commands in `jobs/queue.txt` run from inside `jobs/` and write logs to `jobs/logs/`
(create it first with `mkdir jobs/logs`).

## Replica of the public IEEE 9-bus benchmark (`bench9/`)
`replica.py` rebuilds the dataset design of the public IEEE 9-bus TSA benchmark
(Supreme et al., 2026) from its released MATLAB generation code in ANDES 2.0
(GENROU + ESAC1A + IEEEST, self-clearing bus faults, 80-450 ms, 180-degree label).
    python3 bench9/job.py dense 100 32 901 results/bench9/dense_a.pkl   # see bench9/queue.txt
    python3 bench9/prepare.py      # -> results/data2/b9.pkl, denseb9.json
    python3 bench9/analyze.py      # ceiling, model statistics, table
