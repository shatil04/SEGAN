"""Convert replica shards into (a) graph samples for training (results/data2/b9.pkl)
and (b) dense re-simulation records (results/data2/denseb9.json).
Label convention of the training code: 1 = stable."""
import glob, json, os, pickle, sys
from collections import deque
import numpy as np
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from bench9.replica import LINES, XFMR, GEN

R9 = os.path.join(HERE, "results", "bench9")
D2 = os.path.join(HERE, "results", "data2")
BR = [(a, b, r, x, bb, 1.0) for a, b, r, x, bb in LINES] + [(a, b, r, x, 0.0, 1.0) for a, b, r, x in XFMR]
EI = np.array([[a - 1 for a, b, *_ in BR] + [b - 1 for a, b, *_ in BR],
               [b - 1 for a, b, *_ in BR] + [a - 1 for a, b, *_ in BR]], dtype=np.int64)
EA = np.array([[r, x, bb, t, 0.0] for a, b, r, x, bb, t in BR] * 2, dtype=np.float32)
ADJ = {i: set() for i in range(9)}
for a, b, *_ in BR:
    ADJ[a - 1].add(b - 1); ADJ[b - 1].add(a - 1)


def hops(src):
    d = {src: 0}; q = deque([src])
    while q:
        u = q.popleft()
        for v in ADJ[u]:
            if v not in d:
                d[v] = d[u] + 1; q.append(v)
    return np.array([d[i] for i in range(9)], float)


def graph(c):
    pf = c["pf"]; f = c["fault"]
    x = np.zeros((9, 17), np.float32)
    for b in range(1, 10):
        i = b - 1
        if b in GEN:
            g = GEN[b]
            x[i, 0] = 1; x[i, 4] = g["H"] * g["Sn"] / 100; x[i, 5] = g["Sn"] / 100
            x[i, 6] = g["xd1"] * 100 / g["Sn"]; x[i, 7] = pf["Pg"][i] / 100; x[i, 8] = pf["Qg"][i] / 100
        else:
            x[i, 3] = 1
        x[i, 9] = pf["V"][i]; x[i, 10] = pf["Pd"][i] / 100; x[i, 11] = pf["Qd"][i] / 100
        x[i, 12] = pf["a"][i]
    fb = f["bus"] - 1
    x[fb, 13] = 1.0                       # is_fault
    x[:, 15] = f["duration"]              # clearing time
    x[:, 16] = hops(fb) / 3.0
    return dict(x=x, edge_index=EI, edge_attr=EA.copy(), ntype=np.array([0, 0, 0] + [3] * 6))


def main():
    S = []; nfail = 0
    for p in sorted(glob.glob(os.path.join(R9, "single_*.pkl"))):
        for r in pickle.load(open(p, "rb")):
            c = r["cases"][0]
            if not c.get("ok"):
                nfail += 1; continue
            S.append(dict(graph=graph(c), label=1 - int(c["label"]), rho_cap=0.0, rho_disp=0.0,
                          fault_bus=int(c["fault"]["bus"]), trip_branch=-1,
                          t_clear=float(c["fault"]["duration"]), load_factor=r["op"]["load_factor"],
                          scenario_id=r["op_id"], system="bench9",
                          diag=dict(max_sep=c["max_sep"], finished=c["finished"], kind=c["fault"]["kind"])))
    pickle.dump(dict(samples=S), open(os.path.join(D2, "b9.pkl"), "wb"))
    dense = []
    for p in sorted(glob.glob(os.path.join(R9, "dense_*.pkl"))):
        for r in pickle.load(open(p, "rb")):
            ys = [1 - int(c["label"]) for c in r["cases"] if c.get("ok")]
            if len(ys) == len(r["cases"]):
                dense.append(dict(op_id=r["op_id"], load_factor=r["op"]["load_factor"],
                                  gen_factor=r["op"]["gen_factor"], y=ys))
            else:
                nfail += 1
    json.dump(dense, open(os.path.join(D2, "denseb9.json"), "w"))
    st = np.mean([s["label"] for s in S]) if S else float("nan")
    print(f"single samples {len(S)} (stable {100*st:.1f}%), dense ops {len(dense)}, failed {nfail}")


if __name__ == "__main__":
    main()
