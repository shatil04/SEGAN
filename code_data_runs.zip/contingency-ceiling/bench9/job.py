"""Generate replica data in resumable shards.
  job.py single N SEED OUT.pkl      N fresh operating points, one fault each
  job.py dense  N M SEED OUT.pkl    N operating points, M independent faults each
"""
import os, sys, pickle, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import andes
andes.config_logger(stream_level=50)
from bench9.replica import simulate, draw_op, draw_fault


def save(out, recs):
    tmp = out + ".tmp"
    pickle.dump(recs, open(tmp, "wb")); os.replace(tmp, out)


def run_case(op, f):
    try:
        r = simulate(op, f)
    except Exception as e:                     # numerical failure
        r = dict(ok=False, err=repr(e)[:200])
    return dict(op=op, fault=f, **r)


def main():
    mode = sys.argv[1]
    if mode == "single":
        n, seed, out = int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]; m = 1
    else:
        n, m, seed, out = int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
    recs = pickle.load(open(out, "rb")) if os.path.exists(out) else []
    t0 = time.time(); done0 = len(recs)
    for i in range(len(recs), n):
        rng = np.random.default_rng([seed, i])       # deterministic per operating point
        op = draw_op(rng)
        cases = [run_case(op, draw_fault(rng)) for _ in range(m)]
        recs.append(dict(op_id=f"{seed}_{i}", op=op, cases=cases))
        if (i + 1) % 25 == 0 or i == n - 1:
            save(out, recs)
            rate = (time.time() - t0) / (i + 1 - done0)
            print(f"{out}: {i + 1}/{n}  {rate:.1f} s/op", flush=True)
    save(out, recs)
    print("DONE", out, flush=True)


if __name__ == "__main__":
    main()
