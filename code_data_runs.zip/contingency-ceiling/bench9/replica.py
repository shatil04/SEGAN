"""Replica of the dataset design of the public IEEE 9-bus TSA benchmark
(Supreme et al., 2026), built from its released generator code, in ANDES.

Matched to the released code (config.m, scenario/*.m, labels/*.m, model .slx):
  network     case_IEEE9BusSystem.m (MATPOWER data shipped with the code)
  machines    detailed (subtransient) models with the .slx parameters, AC1C
              exciters (-> ESAC1A) and PSS1A stabilisers (-> IEEEST), constant
              mechanical power, constant-impedance loads
  operating   one load factor U(0.60, 1.25) on all loads (single area), one
  point       generation factor U(0.90, 1.10) on generator dispatch, slack
              balances; power flow must converge
  fault       bolted three-phase-to-ground fault, self-clearing (no branch
              trip); with prob. 0.7 a random non-transformer line is chosen and
              the fault is applied at its from-bus, otherwise a uniform bus;
              duration U(80, 450) ms; 2.0 s simulated from fault inception
  label       unstable if the peak inter-machine rotor-angle separation
              (max - min of angles about their mean) exceeds 180 degrees
Differences: ANDES is a positive-sequence RMS simulator (the benchmark uses
Simscape Electrical); GENROU replaces the salient-pole model of unit 1; the
PSS1A output filter (T6 = 10.6 ms) is omitted.
"""
import numpy as np

BUS = [(1, 16.5), (2, 18.0), (3, 13.8)] + [(b, 230.0) for b in range(4, 10)]
LOADS = {5: (125.0, 50.0), 6: (90.0, 30.0), 8: (100.0, 35.0)}
LINES = [(4, 5, 0.0188405482, 0.105678663, 0.0329056698),
         (4, 6, 0.0235072779, 0.110342949, 0.0269028779),
         (5, 7, 0.0456805293, 0.205356825, 0.0504753031),
         (6, 9, 0.0503478261, 0.211357327, 0.0678056226),
         (7, 8, 0.0178402647, 0.0970128562, 0.0272319346),
         (8, 9, 0.0322816635, 0.165220455, 0.0181419926)]
XFMR = [(4, 1, 0.0002, 0.0576), (7, 2, 0.0002, 0.0625), (9, 3, 0.0002, 0.0586)]
GEN = {  # bus: Sn, P0 (MW), V, H (machine base), xd, xq, xd1, xq1, xd2, xl, Td10, Tq10, Td20, Tq20
    1: dict(Sn=247.5, P=0.0, V=1.04, H=9.5515, xd=0.3614, xq=0.2398, xd1=0.1505, xq1=0.2398,
            xd2=0.0990, xl=0.0832, Td10=8.96, Tq10=0.31, Td20=0.05, Tq20=0.09),
    2: dict(Sn=192.0, P=163.0, V=1.025, H=3.3333, xd=1.7199, xq=1.6598, xd1=0.23, xq1=0.378,
            xd2=0.1728, xl=0.1, Td10=6.0, Tq10=0.535, Td20=0.05, Tq20=0.04),
    3: dict(Sn=128.0, P=85.0, V=1.025, H=2.3516, xd=1.68, xq=1.61, xd1=0.2321, xq1=0.32,
            xd2=0.128, xl=0.095, Td10=5.89, Tq10=0.60, Td20=0.05, Tq20=0.04),
}
AC1C = dict(TR=0.001, TB=0.0, TC=0.0, VAMAX=14.5, VAMIN=-14.5, KA=400.0, TA=0.02,
            VRMAX=6.03, VRMIN=-5.43, TE=0.8, E1=4.18, SE1=0.1, E2=3.14, SE2=0.03,
            KC=0.2, KD=0.38, KE=1.0, KF=0.03, TF=1.0)
PSS1A = dict(MODE=1, A1=0, A2=0, A3=0, A4=0, A5=0, A6=0, T1=0.32, T2=0.016, T3=1.0, T4=1.0,
             T5=1.0, T6=1.0, KS=3.15, LSMAX=0.09, LSMIN=-0.09, VCU=9999, VCL=-9999)
LINE_FROM = [l[0] for l in LINES]


def draw_op(rng):
    return dict(load_factor=float(rng.uniform(0.60, 1.25)), gen_factor=float(rng.uniform(0.90, 1.10)))


def draw_fault(rng):
    if rng.random() < 0.7:
        li = int(rng.integers(len(LINES)))
        return dict(kind="line", line=li, bus=LINE_FROM[li], duration=float(rng.uniform(0.08, 0.45)))
    return dict(kind="bus", line=-1, bus=int(rng.integers(1, 10)), duration=float(rng.uniform(0.08, 0.45)))


def build(op, fault=None, t_fault=0.1):
    import andes
    ss = andes.System(default_config=True, no_output=True)
    ss.undill()
    for b, kv in BUS:
        ss.add("Bus", dict(idx=b, name=f"B{b}", Vn=kv, v0=1.0))
    for i, (a, b, r, x, bb) in enumerate(LINES):
        ss.add("Line", dict(idx=f"L{i}", bus1=a, bus2=b, r=r, x=x, b=bb, Vn1=230, Vn2=230))
    for i, (a, b, r, x) in enumerate(XFMR):
        ss.add("Line", dict(idx=f"T{i}", bus1=a, bus2=b, r=r, x=x, b=0, trans=1, tap=1.0,
                            Vn1=230, Vn2=BUS[b - 1][1]))
    for b, (p, q) in LOADS.items():
        ss.add("PQ", dict(idx=f"PQ{b}", bus=b, p0=p * op["load_factor"] / 100, q0=q * op["load_factor"] / 100,
                          vmax=1.2, vmin=0.8))
    for b, g in GEN.items():
        kw = dict(idx=f"G{b}", bus=b, Sn=g["Sn"], Vn=BUS[b - 1][1], v0=g["V"], vmax=1.5, vmin=0.5,
                  qmax=3, qmin=-3, pmax=9, pmin=-9)
        if b == 1:
            ss.add("Slack", dict(kw, p0=0.0))
        else:
            ss.add("PV", dict(kw, p0=g["P"] * op["gen_factor"] / 100))
        ss.add("GENROU", dict(idx=f"S{b}", bus=b, gen=f"G{b}", Sn=g["Sn"], Vn=BUS[b - 1][1],
                              M=2 * g["H"], D=0.0, ra=0.01, xl=g["xl"], xd=g["xd"], xq=g["xq"],
                              xd1=g["xd1"], xq1=g["xq1"], xd2=g["xd2"], xq2=g["xd2"],
                              Td10=g["Td10"], Tq10=g["Tq10"], Td20=g["Td20"], Tq20=g["Tq20"]))
        ss.add("ESAC1A", dict(AC1C, idx=f"E{b}", syn=f"S{b}"))
        ss.add("IEEEST", dict(PSS1A, idx=f"P{b}", avr=f"E{b}"))
    if fault is not None:
        ss.add("Fault", dict(idx="F1", bus=fault["bus"], tf=t_fault, tc=t_fault + fault["duration"],
                             xf=1e-4, rf=0.0))
    ss.setup()
    return ss


def simulate(op, fault, t_fault=0.1, horizon=2.0):
    """Returns dict(ok, label, max_sep, pf) ; label 1 = unstable."""
    ss = build(op, fault, t_fault)
    if not ss.PFlow.run():
        return dict(ok=False)
    pf = dict(V=np.array(ss.Bus.v.v), a=np.array(ss.Bus.a.v),
              Pd=np.array([LOADS.get(b, (0, 0))[0] * op["load_factor"] for b in range(1, 10)]),
              Qd=np.array([LOADS.get(b, (0, 0))[1] * op["load_factor"] for b in range(1, 10)]),
              Pg=np.array([ss.Slack.p.v[0]] + list(ss.PV.p.v)) * 100,
              Qg=np.array([ss.Slack.q.v[0]] + list(ss.PV.q.v)) * 100)
    ss.TDS.config.tf = t_fault + horizon
    ss.TDS.config.no_tqdm = 1
    ss.TDS.config.tstep = 1 / 30
    ss.TDS.run()
    ts = ss.dae.ts
    d = ts.x[:, ss.GENROU.delta.a]
    rel = d - d.mean(1, keepdims=True)
    sep = np.degrees(rel.max(1) - rel.min(1))
    max_sep = float(np.nanmax(sep)) if len(sep) else np.nan
    finished = ts.t[-1] >= t_fault + horizon - 1e-6 if len(ts.t) else False
    if not finished:          # integration stopped: treat as loss of synchronism
        max_sep = max(max_sep, 360.0)
    return dict(ok=True, label=int(max_sep > 180.0), max_sep=max_sep, pf=pf,
                finished=bool(finished))
