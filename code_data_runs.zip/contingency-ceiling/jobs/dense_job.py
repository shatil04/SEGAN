"""Monte-Carlo estimate of p(x)=P(stable|pre-fault state) per operating point.
Usage: dense_job.py SYSTEM LEVELS NOPS M CLEARING SEED OUT"""
import os, sys, json, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pihgnn.data.gen2 import conditional_stability
system, levels, nops, m, clr, seed, out = sys.argv[1:8]
clearing = tuple(float(x) for x in clr.split(":")) if ":" in clr else [float(x) for x in clr.split(",")]
res, t0 = [], time.time()
for rho in [float(x) for x in levels.split(",")]:
    lr = (0.60, 1.25) if system == "wscc9" else (0.80, 1.15)
    res += conditional_stability(system, rho, int(nops), int(m), clearing,
                                 int(seed) + int(round(rho * 1000)), load_range=lr)
    json.dump(res, open(out, "w"))
    print(f"{system} rho={rho} n={len(res)} t={time.time()-t0:.0f}s", flush=True)
print("DONE", flush=True)
