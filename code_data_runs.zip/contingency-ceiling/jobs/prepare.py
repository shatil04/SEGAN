"""Merge 39-bus shards and build the converter-aware relabelled dataset."""
import os, sys, pickle
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from analysis.analyze3 import relabel
D = os.path.join(HERE, "results", "data2")
S = []
for f in ("s39_a.pkl", "s39_b.pkl"):
    S += pickle.load(open(os.path.join(D, f), "rb"))["samples"]
pickle.dump(dict(samples=S), open(os.path.join(D, "s39.pkl"), "wb"))
yc = relabel(S, pll_end=0.5)
pickle.dump(dict(samples=[dict(s, label=int(l)) for s, l in zip(S, yc)]),
            open(os.path.join(D, "s39_conv.pkl"), "wb"))
print("s39", len(S), "conv changed", sum(int(a != s["label"]) for a, s in zip(yc, S)))
