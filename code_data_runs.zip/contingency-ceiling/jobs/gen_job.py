"""Generate one dataset shard. Usage:
  gen_job.py SYSTEM DESIGN LEVELS OPS K CLEARING SEED CCT OUT
LEVELS: comma list of rho; CLEARING: comma list (discrete) or lo:hi (uniform).
"""
import sys, os, time, pickle
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
from pihgnn.data.gen2 import generate
system, design, levels, ops, k, clr, seed, cct, out = sys.argv[1:10]
levels = [float(x) for x in levels.split(",")]
clearing = tuple(float(x) for x in clr.split(":")) if ":" in clr else [float(x) for x in clr.split(",")]
t0 = time.time(); allS = []
for i, rho in enumerate(levels):
    lr = (0.60, 1.25) if system == "wscc9" else (0.80, 1.15)   # 9-bus: public-benchmark load range
    s = generate(system, [rho], int(ops), int(k), clearing, int(seed) + int(round(rho * 1000)),
                 compute_cct=(cct == "1"), design=design, load_range=lr)
    allS += s
    print(f"{system} rho={rho:.2f} n={len(s)} stable={np.mean([x['label'] for x in s]):.3f} t={time.time()-t0:.0f}s", flush=True)
    pickle.dump(dict(samples=allS), open(out, "wb"))
print("DONE", len(allS), flush=True)
