"""Numerical validation: undisturbed drift and step-halving agreement."""
import os, sys, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pihgnn.data.gen2 import make_op, draw_contingency
from pihgnn.data.systems import get_system
from pihgnn.data import dynamics as dyn
which = sys.argv[1]
out = {}
if which == "drift":
    for name, levels in (("wscc9", [0, .25, .5]), ("ieee39", [0, .2, .4, .6, .8]), ("npcc", [0, .4, .8])):
        S = get_system(name); rng = np.random.default_rng(11); worst = 0.0
        for rho in levels:
            for _ in range(3):
                op = make_op(S, rho, rng)
                if op is None: continue
                case, net, y0, lay, _ = op
                t, Y = dyn.simulate(net, y0, lay, int(net.bus_ids[0]), None, t_clear=0.0, t_end=4.0, dt=dyn.DT)
                sg = [(b, sl.start) for (b, ty, sl) in lay if ty != "GFL"]
                H = np.array([net.devices[b].get("H", net.devices[b].get("J", 3.0)) for b, _ in sg])
                A = np.array([Y[i] for _, i in sg]); coi = (H[:, None] * A).sum(0) / H.sum()
                rel = A - coi
                worst = max(worst, float(np.rad2deg(np.abs(rel - rel[:, [0]])).max()))
        out[name] = worst
        print(name, "max COI-relative drift (deg):", worst, flush=True)
else:
    n = int(sys.argv[2]); agree = tot = 0
    for name, levels, clr in (("ieee39", [0, .4, .8], [0.04, 0.06, 0.08, 0.10, 0.12, 0.15, 0.18, 0.22]),
                              ("wscc9", [0, .25, .5], (0.08, 0.45))):
        S = get_system(name); rng = np.random.default_rng(23); a = c = 0
        while c < n:
            op = make_op(S, float(rng.choice(levels)), rng)
            if op is None: continue
            case, net, y0, lay, _ = op
            fb, tb, tc = draw_contingency(case, net, rng, clr)
            l1, _ = dyn.label_and_diagnostics(net, y0, lay, fb, tb, tc, dt=0.01)
            l2, _ = dyn.label_and_diagnostics(net, y0, lay, fb, tb, tc, dt=0.005)
            a += int(l1 == l2); c += 1
        out[name] = dict(agree=a, n=c); agree += a; tot += c
        print(name, "label agreement 10ms vs 5ms:", a, "/", c, flush=True)
    out["total"] = dict(agree=agree, n=tot)
json.dump(out, open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results", f"checks3_{which}.json"), "w"), indent=1)
